#include "game/game_app.hpp"
#include "game/ui/layout.hpp"
#include "game/util/world_math.hpp"
#include "game/world/world_labels.hpp"
#include "game/version.hpp"
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <limits>
#include <sstream>

namespace game {
using namespace game::runtime;
using namespace layout;
using namespace world_math;
using namespace world_labels;

void GameApp::ensure_display_modes(){
    if(!display_modes_.empty()) return;

    const DisplayMode current=app_.current_display_mode();
    const auto supported=app_.display_modes();

    for(const auto& common:COMMON_RESOLUTIONS){
        const auto it=std::find_if(supported.begin(),supported.end(),[&](const DisplayMode& mode){
            return mode.width==common.width && mode.height==common.height;
        });
        if(it!=supported.end()) display_modes_.push_back(*it);
    }

    if(current.width>0 && current.height>0){
        const bool already_listed=std::any_of(display_modes_.begin(),display_modes_.end(),[&](const DisplayMode& mode){
            return mode.width==current.width && mode.height==current.height;
        });
        if(!already_listed) display_modes_.push_back(current);
    }

    if(display_modes_.empty()) display_modes_.push_back(current.width>0?current:DisplayMode{1600,900,0});

    display_mode_index_=0;
    for(size_t i=0;i<display_modes_.size();++i){
        if(display_modes_[i].width==current.width && display_modes_[i].height==current.height){
            display_mode_index_=(int)i;
            break;
        }
    }
}

void GameApp::render_settings(SceneRenderer& r){
    ensure_display_modes();
    ui::title(r,{32,24},"SETTINGS",theme_);

    const float logical_w=ui_width(r);
    const float logical_h=ui_height(r);
    const float w=std::min(820.0f,logical_w-2.0f*SCREEN_MARGIN);
    const float h=std::min(470.0f,logical_h-92.0f);
    Rect p={(logical_w-w)*0.5f,70,w,h};
    ui::panel(r,p,theme_);

    const float inner_x=p.x+PANEL_PADDING;
    const float inner_y=p.y+18.0f;
    const float inner_w=p.w-2.0f*PANEL_PADDING;
    const float column_gap=SECTION_GAP+4.0f;
    const float column_w=(inner_w-column_gap)*0.5f;
    const float left_x=inner_x;
    const float right_x=inner_x+column_w+column_gap;
    const float separator_x=inner_x+column_w+column_gap*0.5f;

    ui::label(r,{left_x,inner_y},"DISPLAY",1.18f,theme_);
    ui::label(r,{left_x,inner_y+39},"FULLSCREEN",0.92f,theme_);
    const bool fullscreen=app_.fullscreen();
    if(ui::button(r,ui_input_,{left_x+column_w-82,inner_y+27,82,34},fullscreen?"ON":"OFF",theme_))
        app_.set_fullscreen(!fullscreen);

    ui::label(r,{left_x,inner_y+78},"UI SCALE",0.92f,theme_);
    const float small_button=38.0f;
    const float control_right=left_x+column_w;
    if(ui::button(r,ui_input_,{control_right-150,inner_y+66,small_button,34},"<",theme_) && ui_scale_index_>0){
        --ui_scale_index_;persist_preferences();
        // Apply the new zoom at the next frame boundary with matching input/drawing.
    }
    std::ostringstream scale;
    scale<<(int)std::lround(UI_SCALES[ui_scale_index_]*100.0f)<<"%";
    ui::label(r,{control_right-99,inner_y+78},scale.str(),0.94f,theme_);
    if(ui::button(r,ui_input_,{control_right-small_button,inner_y+66,small_button,34},">",theme_) && ui_scale_index_<UI_SCALE_COUNT-1){
        ++ui_scale_index_;persist_preferences();
        // Apply the new zoom at the next frame boundary with matching input/drawing.
    }

    ui::label(r,{left_x,inner_y+119},"RESOLUTION",0.92f,theme_);
    if(ui::button(r,ui_input_,{control_right-190,inner_y+107,small_button,34},"<",theme_,display_mode_index_>0)){
        --display_mode_index_;
    }
    if(ui::button(r,ui_input_,{control_right-small_button,inner_y+107,small_button,34},">",theme_,
                  display_mode_index_<static_cast<int>(display_modes_.size())-1)){
        ++display_mode_index_;
    }
    const auto& mode=display_modes_[(size_t)std::max(0,display_mode_index_)];
    std::ostringstream resolution;
    resolution<<mode.width<<" X "<<mode.height;
    ui::label(r,{control_right-140,inner_y+119},resolution.str(),0.86f,theme_);

    if(ui::button(r,ui_input_,{control_right-112,inner_y+151,112,34},"APPLY",theme_)){
        if(app_.set_display_mode(mode.width,mode.height)){preferred_display_mode_=mode;persist_preferences();}
    }
    ui::label(r,{left_x,inner_y+158},"COMMON SUPPORTED MODES",0.72f,theme_,true);
    ui::label_fitted(r,{left_x,inner_y+202,std::max(10.f,column_w-160.f),18},"FIRST PERSON FOV",.92f,theme_);
    const auto set_fov=[&](float degrees){first_person_.set_fov(degrees);persist_preferences();};
    if(ui::button(r,ui_input_,{control_right-150,inner_y+190,38,34},"<",theme_,first_person_.fov()>50))set_fov(first_person_.fov()-2);
    ui::label_fitted(r,{control_right-105,inner_y+202,62,18},std::to_string(int(first_person_.fov()))+" DEG",.9f,theme_);
    if(ui::button(r,ui_input_,{control_right-38,inner_y+190,38,34},">",theme_,first_person_.fov()<110))set_fov(first_person_.fov()+2);
    if(ui::button(r,ui_input_,{left_x,inner_y+238,column_w,34},"GRAPHICS",theme_)){
        screen_=Screen::GraphicsSettings;
        graphics_tab_=graphics_page_=0;
        graphics_dropdown_=-1;
        graphics_display_failed_=false;
    }

    r.draw_line({separator_x,p.y+16},{separator_x,p.y+p.h-58},theme_.border,1.0f);

    const float right_edge=right_x+column_w;
    ui::label(r,{right_x,inner_y},"GAMEPLAY",1.18f,theme_);
    ui::label_fitted(r,{right_x,inner_y+39,column_w-158,18},"AUTOSAVE",.92f,theme_);
    const auto set_interval=[&](int minutes){autosave_minutes_=std::clamp(minutes,0,60);reset_autosave();persist_preferences();};
    if(ui::button(r,ui_input_,{right_edge-150,inner_y+27,38,34},"-",theme_,autosave_minutes_>0))set_interval(autosave_minutes_<=5?0:autosave_minutes_-5);
    ui::label_fitted(r,{right_edge-106,inner_y+39,64,18},autosave_minutes_?std::to_string(autosave_minutes_)+" MIN":"OFF",.86f,theme_);
    if(ui::button(r,ui_input_,{right_edge-38,inner_y+27,38,34},"+",theme_,autosave_minutes_<60))set_interval(autosave_minutes_==0?5:autosave_minutes_+5);
    ui::label(r,{right_x,inner_y+80},"FPS COUNTER",.92f,theme_);
    if(ui::button(r,ui_input_,{right_edge-82,inner_y+68,82,34},show_fps_?"ON":"OFF",theme_)){
        show_fps_=!show_fps_;persist_preferences();
    }
    if constexpr(build::debug_features){
        ui::label(r,{right_x,inner_y+121},"DEBUG FRAME",0.92f,theme_);
        const std::string debug_label=debug_frame_enabled_?"ON":"OFF";
        if(ui::button(r,ui_input_,{right_x+column_w-82,inner_y+109,82,34},debug_label,theme_)){
            debug_frame_enabled_=!debug_frame_enabled_;persist_preferences();
        }
        ui::label(r,{right_x,inner_y+162},"DEBUG LAYOUT",0.92f,theme_);
        if(ui::button(r,ui_input_,{right_edge-148,inner_y+150,148,34},
                      mesh_layout_active()?"MESHED":"FULL GRAPHICS",theme_))
            toggle_world_layout();
    }

    const float audio_y=inner_y+(build::debug_features?201.0f:121.0f);
    ui::label(r,{right_x,audio_y},"AUDIO",1.18f,theme_);
    ui::label(r,{right_x,audio_y+38},"MUSIC",0.92f,theme_);
    if(ui::button(r,ui_input_,{right_edge-82,audio_y+26,82,34},soundscape_.music_enabled()?"ON":"OFF",theme_)){
        soundscape_.set_music_enabled(!soundscape_.music_enabled());
        persist_preferences();
    }

    const float volume=soundscape_.volume();
    ui::label(r,{right_x,audio_y+80},"SOUND VOLUME",0.92f,theme_);
    if(ui::button(r,ui_input_,{right_edge-150,audio_y+68,small_button,34},"-",theme_)){
        soundscape_.set_volume(volume-.10f);persist_preferences();
    }
    ui::label(r,{right_edge-99,audio_y+80},std::to_string((int)std::lround(volume*100.0f))+"%",0.91f,theme_);
    if(ui::button(r,ui_input_,{right_edge-small_button,audio_y+68,small_button,34},"+",theme_)){
        soundscape_.set_volume(volume+.10f);persist_preferences();
    }
    if(ui::button(r,ui_input_,{right_edge-112,audio_y+108,112,34},volume>0.0f?"MUTE":"UNMUTE",theme_)){
        soundscape_.set_volume(volume>0.0f?0.0f:.72f);persist_preferences();
    }

    if(preferences_save_failed_)
        ui::label_fitted(r,{left_x,inner_y+288,column_w,24},"PREFERENCES COULD NOT BE SAVED",0.78f,theme_);

    constexpr float back_w=130.0f;
    constexpr float back_h=38.0f;
    if(ui::button(r,ui_input_,{p.x+PANEL_PADDING,p.y+p.h-PANEL_PADDING-back_h,back_w,back_h},"BACK",theme_)){
        screen_=Screen::MainMenu;
    }
}

} // namespace game
