#include "game/config/preferences.hpp"
#include <algorithm>
#include <charconv>
#include <cmath>
#include "game/ui/layout.hpp"
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <string_view>
#ifdef _WIN32
#include <process.h>
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#else
#include <unistd.h>
#endif

namespace game {
namespace {
using namespace game::runtime;

std::filesystem::path config_path(bool legacy=false){
#ifdef _WIN32
    if(const wchar_t* path=_wgetenv(L"GAME_SETTINGS_CONFIG"); path && *path) return path;
    if(const wchar_t* path=_wgetenv(L"GAME_GRAPHICS_CONFIG"); path && *path) return path;
    if(const wchar_t* appdata=_wgetenv(L"APPDATA"); appdata && *appdata)
        return std::filesystem::path(appdata)/"Lunar Frontier"/(legacy?"graphics.cfg":"settings.cfg");
#else
    if(const char* path=std::getenv("GAME_SETTINGS_CONFIG"); path && *path) return path;
    if(const char* path=std::getenv("GAME_GRAPHICS_CONFIG"); path && *path) return path;
    if(const char* xdg=std::getenv("XDG_CONFIG_HOME"); xdg && *xdg)
        return std::filesystem::path(xdg)/"lunar-frontier"/(legacy?"graphics.cfg":"settings.cfg");
    if(const char* home=std::getenv("HOME"); home && *home)
        return std::filesystem::path(home)/".config"/"lunar-frontier"/(legacy?"graphics.cfg":"settings.cfg");
#endif
    return {};
}

constexpr std::pair<const char*,int GraphicsSettings::*> numbers[]{
    {"render_scale",&GraphicsSettings::render_scale},{"ray_scale",&GraphicsSettings::ray_scale},
    {"bloom",&GraphicsSettings::bloom},{"exposure_tenths",&GraphicsSettings::exposure_tenths},
    {"aa_quality",&GraphicsSettings::aa_quality},{"shadow_quality",&GraphicsSettings::shadow_quality},
    {"bloom_quality",&GraphicsSettings::bloom_quality},
    {"surface_resolution",&GraphicsSettings::surface_resolution},{"texture_filter",&GraphicsSettings::texture_filter},
    {"shadow_resolution",&GraphicsSettings::shadow_resolution},{"ground_clutter",&GraphicsSettings::ground_clutter},
    {"clutter_range",&GraphicsSettings::clutter_range},{"particle_density",&GraphicsSettings::particle_density}
};
}

Preferences load_preferences(){
    Preferences preferences{game::runtime::graphics_settings_from_environment()};
    auto& settings=preferences.graphics;
    std::uint32_t explicit_quality{};
    if(const char* level=std::getenv("GAME_SOUND_VOLUME")){
        char* end=nullptr;const auto volume=std::strtof(level,&end);
        if(end!=level&&!*end&&std::isfinite(volume))preferences.sound_volume_percent=int(std::lround(std::clamp(volume,0.f,100.f)));
    }
    std::ifstream file(config_path());
    if(!file&&config_path()!=config_path(true)){file.clear();file.open(config_path(true));}
    for(std::string line;std::getline(file,line);){
        if(!line.empty() && line.back()=='\r') line.pop_back();
        const auto separator=line.find('=');
        if(separator==std::string::npos || separator+1==line.size()) continue;
        const std::string_view key(line.data(),separator);
        const char* first=line.data()+separator+1;
        const char* last=line.data()+line.size();
        int value{};
        const auto parsed=std::from_chars(first,last,value);
        if(parsed.ec!=std::errc{} || parsed.ptr!=last) continue;
        if(key=="ui_scale_index")preferences.ui_scale_index=std::clamp(value,0,layout::UI_SCALE_COUNT-1);
        if(key=="faded_hulls")preferences.faded_hulls=value==1;
        if(key=="sound_volume_percent")preferences.sound_volume_percent=std::clamp(value,0,100);
        if(key=="debug_frame")preferences.debug_frame_enabled=value==1;
        if(key=="display_width")preferences.display_width=value>=640&&value<=16384?value:0;
        if(key=="display_height")preferences.display_height=value>=480&&value<=16384?value:0;
        if(key=="show_fps")preferences.show_fps=value==1;
        if(key=="autosave_minutes")preferences.autosave_minutes=std::clamp(value,0,60);
        if(key=="first_person_fov")preferences.first_person_fov=std::clamp(value,50,110);
        if(key=="path" && value>=0 && value<=2) settings.path=static_cast<GraphicsPath>(value);
        if(key=="aa" && value>=0 && value<=2) settings.aa=static_cast<GraphicsAA>(value);
        if(key=="shadows" && value>=0 && value<=2) settings.shadows=static_cast<GraphicsShadows>(value);
        if(key=="transparency" && value>=0 && value<=1) settings.transparency=static_cast<GraphicsTransparency>(value);
        for(const auto& [name,field]:numbers) if(key==name) settings.*field=value;
        if(key.ends_with("_quality") && value>=1 && value<=3){
            const auto name=key.substr(0,key.size()-8);
            const auto it=std::find(graphics_feature_keys.begin(),graphics_feature_keys.end(),name);
            if(it!=graphics_feature_keys.end()){
                const auto feature=static_cast<GraphicsFeature>(it-graphics_feature_keys.begin());
                if(scalable_graphics_feature(feature)){
                    explicit_quality|=graphics_bit(feature);
                    const bool enabled=settings.enabled(feature);
                    settings.set_quality(feature,value);
                    settings.set(feature,enabled);
                }
            }
        }
        if(value!=0 && value!=1) continue;
        if(key=="vertical_sync") settings.vertical_sync=value==1;
        if(key=="mesh_layout") preferences.mesh_layout=value==1;
        if(key=="music") preferences.music_enabled=value==1;
#ifdef _WIN32
        if(key=="terrain_vrs") settings.terrain_vrs=value==1;
#endif
        const auto it=std::find(graphics_feature_keys.begin(),graphics_feature_keys.end(),key);
        if(it!=graphics_feature_keys.end()){
            const auto feature=static_cast<GraphicsFeature>(it-graphics_feature_keys.begin());
            if(value==1 && scalable_graphics_feature(feature) && !(explicit_quality&graphics_bit(feature)))
                settings.set_quality(feature,3);
            else settings.set(feature,value==1);
        }
    }
    settings.normalize();
    return preferences;
}

bool save_preferences(const Preferences& preferences){
    const auto& settings=preferences.graphics;
    const auto path=config_path();
    if(path.empty()) return false;
    std::error_code error;
    if(!path.parent_path().empty()) std::filesystem::create_directories(path.parent_path(),error);
    if(error) return false;
    auto temporary=path;
#ifdef _WIN32
    const auto process_id=_getpid();
#else
    const auto process_id=getpid();
#endif
    temporary+="."+std::to_string(process_id)+".tmp";
    std::ofstream file(temporary,std::ios::trunc);
    if(!file) return false;
    file<<"path="<<int(settings.path)<<'\n'<<"aa="<<int(settings.aa)<<'\n'
        <<"shadows="<<int(settings.shadows)<<'\n'<<"transparency="<<int(settings.transparency)<<'\n';
    for(const auto& [name,field]:numbers) file<<name<<'='<<settings.*field<<'\n';
    for(std::size_t i=0;i<graphics_feature_keys.size();++i)
        file<<graphics_feature_keys[i]<<'='<<settings.enabled(static_cast<GraphicsFeature>(i))<<'\n';
    for(const auto feature:scalable_graphics_features){
        const auto bit=graphics_bit(feature);
        const int quality=(settings.low_quality&bit)?1:(settings.medium_quality&bit)?2:3;
        file<<graphics_feature_keys[static_cast<unsigned>(feature)]<<"_quality="<<quality<<'\n';
    }
    file<<"ui_scale_index="<<std::clamp(preferences.ui_scale_index,0,layout::UI_SCALE_COUNT-1)<<'\n'
        <<"faded_hulls="<<preferences.faded_hulls<<'\n'
        <<"sound_volume_percent="<<std::clamp(preferences.sound_volume_percent,0,100)<<'\n'
        <<"debug_frame="<<preferences.debug_frame_enabled<<'\n'
        <<"display_width="<<preferences.display_width<<'\n'
        <<"display_height="<<preferences.display_height<<'\n';
    file<<"autosave_minutes="<<std::clamp(preferences.autosave_minutes,0,60)<<'\n';
    file<<"show_fps="<<preferences.show_fps<<'\n';
    file<<"first_person_fov="<<std::clamp(preferences.first_person_fov,50,110)<<'\n';
    file<<"vertical_sync="<<settings.vertical_sync<<'\n';
    file<<"mesh_layout="<<preferences.mesh_layout<<'\n'
        <<"music="<<preferences.music_enabled<<'\n';
#ifdef _WIN32
    file<<"terrain_vrs="<<settings.terrain_vrs<<'\n';
#endif
    file.close();
    if(file){
#ifdef _WIN32
        if(MoveFileExW(temporary.c_str(),path.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH))return true;
#else
        std::filesystem::rename(temporary,path,error);
        if(!error)return true;
#endif
    }
    std::filesystem::remove(temporary,error);
    return false;
}
} // namespace game
