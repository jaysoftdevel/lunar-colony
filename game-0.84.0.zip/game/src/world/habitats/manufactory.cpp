#include "game/world/habitat_builder.hpp"
#include "game/world/interior_station.hpp"
#include "game/world/habitats/habitat_module.hpp"

namespace game::habitats {
namespace {
void crane_arm(Builder& b,game::runtime::Vec3 root,float side){
    using namespace game::runtime;
    Vec3 a=root;
    Vec3 c=a+Vec3{1.85f*side,0.25f,0};
    Vec3 d=c+Vec3{1.45f*side,-0.9f,0};
    b.cylinder_y(b.mesh.details,a,0.55f,0.34f,12,true);
    b.cylinder_between(b.mesh.details,a,c,0.24f,10,true,true);
    b.cylinder_between(b.mesh.details,c,d,0.22f,10,true,true);
    b.cylinder_y(b.mesh.details,c,0.42f,0.38f,12,true);
    b.box(b.mesh.details,d,{0.85f,0.55f,1.4f});
}
}

void build_manufactory_outer(Builder& b){
    b.mesh.footprint_x=21.0f; b.mesh.footprint_z=14.0f; b.mesh.height=10.8f;
    b.box(b.mesh.foundation,{0,0.62f,0},{15.2f,1.24f,9.8f});

    // Massive fabrication chamber plus long production pressure cylinder.
    b.box(b.mesh.shell,{-3.4f,3.9f,0},{8.6f,6.2f,8.5f});
    b.cylinder_x(b.mesh.shell,{4.2f,3.65f,0},8.8f,3.0f,20,true);
    for(float x:{1.2f,3.5f,5.8f,7.8f}) b.torus_x(b.mesh.details,{x,3.65f,0},3.03f,0.10f,20,6);

    // Huge assembly opening / internal handling platform.
    b.box(b.mesh.details,{-7.45f,4.0f,-4.45f},{0.5f,6.5f,0.5f});
    b.box(b.mesh.details,{0.15f,4.0f,-4.45f},{0.5f,6.5f,0.5f});
    b.box(b.mesh.details,{-3.65f,7.1f,-4.45f},{8.1f,0.48f,0.5f});
    b.box(b.mesh.details,{-3.65f,1.3f,-4.45f},{8.1f,0.42f,0.5f});

    {
    interior_layout::StationScope installed_process_equipment(b.mesh);
    // Large external crane arms and cargo fixtures.
    crane_arm(b,{1.1f,9.2f,2.75f},1.0f);
    crane_arm(b,{5.0f,8.9f,-2.8f},1.0f);
    for(int row=0;row<2;++row) for(int col=0;col<3;++col)
        b.box(b.mesh.details,{-7.15f+1.45f*col,1.55f+0.78f*row,3.7f},{1.15f,0.60f,1.2f});

    // Dense service piping / tanks / rooftop process drums.
    for(float x:{-1.5f,1.4f,4.1f}) b.cylinder_y(b.mesh.details,{x,8.15f,-1.0f},2.0f,0.55f,14,true);
    for(int i=0;i<5;++i){
        float z=-2.7f+1.35f*i;
        b.cylinder_between(b.mesh.details,{0.3f,6.2f,z},{5.8f,6.45f,z},0.09f,8,true,true);
    }
    b.box(b.mesh.details,{6.6f,7.65f,2.4f},{1.8f,1.8f,0.65f});

    }

    b.supports(-6.4f,6.9f,3.4f,1.05f);
    b.supports(-6.4f,6.9f,-3.4f,1.05f);
}
}
