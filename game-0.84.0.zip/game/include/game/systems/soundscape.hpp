#pragma once

#include "game/runtime/audio.hpp"
#include "game/systems/sound_assets.hpp"
#include "game/systems/footstep_cadence.hpp"
#include <array>
#include <future>
#include <optional>
#include <unordered_map>

namespace game::sound {

class Soundscape {
public:
    Soundscape();
    float volume() const { return volume_; }
    void set_volume(float volume);
    bool music_enabled() const { return music_enabled_; }
    void set_music_enabled(bool enabled);
    bool begin(game::runtime::Vec3 listener,game::runtime::Vec3 direction,game::runtime::Vec3 up);
    void finish(float dt);
    void play(Cue cue,const game::runtime::SoundVoice& voice);
    void loop(std::uint64_t key,Cue cue,const game::runtime::SoundVoice& voice,std::size_t variant=0);
    std::optional<std::uint64_t> observe(std::uint64_t key,std::uint64_t value);

    game::runtime::Vec3 feet{};
    FootstepCadence footsteps;
    bool tracking_feet{},grounded{};
    float warning_cooldown{};
    float completion_cooldown{};
    float launch_seconds{};

private:
    struct Observation { std::uint64_t frame{},value{}; };
    game::runtime::Audio::Clip clip(Cue cue,std::size_t variant);
    void update_music();
    game::runtime::Audio audio_;
    std::future<std::vector<std::int16_t>> theme_job_;
    game::runtime::Audio::Clip theme_clip_{};
    bool music_enabled_{true};
    bool theme_requested_{};
    std::array<std::array<game::runtime::Audio::Clip,max_variants>,cue_count> clips_{};
    std::array<std::array<bool,max_variants>,cue_count> attempted_{};
    std::unordered_map<std::uint64_t,Observation> observations_;
    std::uint64_t frame_{};
    std::uint32_t variant_counter_{};
    float volume_{.72f};
    bool initialized_{};
};

} // namespace game::sound
