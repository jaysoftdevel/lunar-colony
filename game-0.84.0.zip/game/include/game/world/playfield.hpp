#pragma once
#include "game/runtime/presentation.hpp"
#include <vector>

namespace game {
class Playfield {
public:
    void rebuild(int size);
    void draw_surface(game::runtime::SceneRenderer& renderer,float daylight) const;
    int size() const { return size_; }
    const std::vector<game::runtime::Vec3>& floor_triangles() const { return floor_tris_; }
    const std::vector<game::runtime::Vec3>& grid_lines() const { return grid_lines_; }
private:
    int size_=64;
    std::vector<game::runtime::Vec3> floor_tris_;
    std::vector<game::runtime::Vec3> grid_lines_;
};
}
