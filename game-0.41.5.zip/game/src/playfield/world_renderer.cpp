#include "game/game_app.hpp"
#include "game/world/mesh_portals.hpp"
#include "game/ui/layout.hpp"
#include "game/util/world_math.hpp"
#include "game/util/mesh_wireframe.hpp"
#include "game/world/construction_sequence.hpp"
#include "game/world/geometry_standards.hpp"
#include "game/world/world_labels.hpp"
#include "game/version.hpp"
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <limits>
#include <sstream>

namespace game {
using namespace eng;
using namespace layout;
using namespace world_math;
using namespace world_labels;

namespace {
std::vector<Vec3> construction_path_lines(const std::vector<Vec3>& path){
    std::vector<Vec3> lines;
    if(path.size()<2) return lines;
    lines.reserve((path.size()-1)*2);
    for(std::size_t i=0;i+1<path.size();++i){
        lines.push_back(path[i]);
        lines.push_back(path[i+1]);
    }
    return lines;
}

bool entrance_access_hits_corridor(const HabitatEntranceAccess& access,Vec3 structure_position,float rotation_degrees,
                                  const CorridorNetwork& network){
    // Authored exterior stairs/ramps are only surface-access geometry.  If a
    // pressurised corridor occupies that volume, hide the access set instead
    // of rendering stairs through the pressure tube.
    const float clearance=geometry::kCorridorHalfWidth+0.18f;
    auto vertex_hits=[&](Vec3 local){
        const Vec3 world=world_math::rotate_y(local,rotation_degrees)+structure_position;
        for(const auto& corridor:network.connections()){
            if(corridor.path.size()<2) continue;
            for(std::size_t i=0;i+1<corridor.path.size();++i){
                if(world_math::point_segment_distance_xz(world,corridor.path[i],corridor.path[i+1])<clearance) return true;
            }
        }
        return false;
    };
    for(const Vec3& v:access.details) if(vertex_hits(v)) return true;
    for(const Vec3& v:access.edges) if(vertex_hits(v)) return true;
    return false;
}

Color resource_box_color(MaterialResource resource){
    switch(resource){
        case MaterialResource::Iron: return {0.48f,0.52f,0.56f,1.0f};
        case MaterialResource::Copper: return {0.74f,0.42f,0.20f,1.0f};
        case MaterialResource::Silicon: return {0.28f,0.58f,0.76f,1.0f};
        case MaterialResource::Plastic: return {0.72f,0.70f,0.58f,1.0f};
        case MaterialResource::Water: return {0.22f,0.58f,0.86f,1.0f};
        case MaterialResource::Food: return {0.48f,0.72f,0.28f,1.0f};
        case MaterialResource::Medical: return {0.88f,0.42f,0.48f,1.0f};
        case MaterialResource::Aluminum: return {0.72f,0.78f,0.84f,1.0f};
        case MaterialResource::Count: break;
    }
    return {0.6f,0.6f,0.6f,1.0f};
}

void draw_resource_box(Renderer& r,Vec3 base,float half_width,float height,MaterialResource resource,bool selected=false){
    const Vec3 c=base+Vec3{0,height*0.5f+0.025f,0};
    const float x0=c.x-half_width,x1=c.x+half_width,z0=c.z-half_width,z1=c.z+half_width,y0=c.y-height*0.5f,y1=c.y+height*0.5f;
    const std::vector<Vec3> tris{
        {x0,y0,z0},{x1,y0,z0},{x1,y0,z1},{x0,y0,z0},{x1,y0,z1},{x0,y0,z1},
        {x0,y1,z0},{x1,y1,z1},{x1,y1,z0},{x0,y1,z0},{x0,y1,z1},{x1,y1,z1},
        {x0,y0,z0},{x0,y1,z0},{x1,y1,z0},{x0,y0,z0},{x1,y1,z0},{x1,y0,z0},
        {x1,y0,z1},{x1,y1,z1},{x0,y1,z1},{x1,y0,z1},{x0,y1,z1},{x0,y0,z1},
        {x0,y0,z1},{x0,y1,z1},{x0,y1,z0},{x0,y0,z1},{x0,y1,z0},{x0,y0,z0},
        {x1,y0,z0},{x1,y1,z0},{x1,y1,z1},{x1,y0,z0},{x1,y1,z1},{x1,y0,z1}
    };
    const std::vector<Vec3> edges{
        {x0,y0,z0},{x1,y0,z0},{x1,y0,z0},{x1,y0,z1},{x1,y0,z1},{x0,y0,z1},{x0,y0,z1},{x0,y0,z0},
        {x0,y1,z0},{x1,y1,z0},{x1,y1,z0},{x1,y1,z1},{x1,y1,z1},{x0,y1,z1},{x0,y1,z1},{x0,y1,z0},
        {x0,y0,z0},{x0,y1,z0},{x1,y0,z0},{x1,y1,z0},{x1,y0,z1},{x1,y1,z1},{x0,y0,z1},{x0,y1,z1}
    };
    const Color base_color=resource_box_color(resource);
    r.draw_triangles_3d(tris,{base_color.r,base_color.g,base_color.b,0.90f});
    r.draw_lines_3d(edges,selected?Color{0.34f,1.00f,0.72f,1.0f}:Color{0.10f,0.12f,0.13f,1.0f},selected?2.8f:1.25f);
}


const std::vector<Vec3>& portal_layer(const std::vector<Vec3>& triangles,Vec3 position,float rotation,
                                       const std::vector<CorridorDoor>* doors,bool lines=false,bool foundation=false){
    if(!doors || doors->empty()) return triangles;
    struct Cache {
        const Vec3* source{};std::size_t size{};bool lines{};
        std::vector<mesh_portals::Aperture> openings;
        std::vector<Vec3> triangles;
    };
    static std::vector<Cache> cache;
    std::vector<mesh_portals::Aperture> openings;
    for(const auto& door:*doors){
        const Vec3 center=rotate_y(door.wall_position-position,-rotation);
        openings.push_back({center,rotate_y(door.normal,-rotation),0.90f,
            geometry::kDoorClearWidth*0.5f,foundation?geometry::kCorridorDeckY-position.y-0.15f:door.position.y-position.y+0.015f,
            door.position.y-position.y+geometry::kDoorClearHeight});
    }
    for(const auto& entry:cache){
        if(entry.source!=triangles.data() || entry.size!=triangles.size() || entry.lines!=lines || entry.openings.size()!=openings.size()) continue;
        bool same=true;
        for(std::size_t i=0;i<openings.size();++i){
            const auto& a=openings[i];const auto& b=entry.openings[i];
            same=same && length(a.center-b.center)<0.0001f && length(a.normal-b.normal)<0.0001f &&
                std::abs(a.bottom-b.bottom)<0.0001f && std::abs(a.top-b.top)<0.0001f;
        }
        if(same) return entry.triangles;
    }
    if(cache.size()>256) cache.clear();
    Cache entry{triangles.data(),triangles.size(),lines,openings,triangles};
    for(const auto& opening:openings) entry.triangles=lines?mesh_portals::subtract_lines(entry.triangles,opening):mesh_portals::subtract(entry.triangles,opening);
    cache.push_back(std::move(entry));
    return cache.back().triangles;
}

void draw_sliding_door(Renderer& r,const CorridorDoor& door,float open_fraction){
    Vec3 n=door.normal; n.y=0.0f; n=normalize(n);
    if(length(n)<0.001f) n={1,0,0};
    const Vec3 side{-n.z,0,n.x};
    const float base_y=door.position.y;
    const float panel_h=2.48f;
    const float panel_half=0.52f;
    const float slide=0.84f*std::clamp(open_fraction,0.0f,1.0f);
    const Vec3 base{door.wall_position.x,base_y+panel_h*0.5f,door.wall_position.z};
    const Color fill{0.30f,0.39f,0.43f,0.96f};
    const Color edge_color{0.08f,0.13f,0.15f,1.0f};
    for(int sign:{-1,1}){
        const float center_side=(float)sign*(panel_half+slide);
        const Vec3 center=base+side*center_side+n*0.035f;
        const Vec3 s=side*panel_half;
        const Vec3 u{0,panel_h*0.5f,0};
        const Vec3 p0=center-s-u,p1=center+s-u,p2=center+s+u,p3=center-s+u;
        (void)fill;
        r.draw_lines_3d({p0,p1,p1,p2,p2,p3,p3,p0},edge_color,2.15f);
    }
}
}

void GameApp::render_habitat_mesh(Renderer& r,const HabitatMesh& mesh,Vec3 position,float rotation_degrees,bool preview,bool valid,bool selected,float construction_step,const std::vector<CorridorDoor>* fpv_doors) const {
    if(preview){
        const auto shell=transformed_vertices(portal_layer(mesh.shell,position,rotation_degrees,fpv_doors),position,rotation_degrees);
        const auto foundation=transformed_vertices(portal_layer(mesh.foundation,position,rotation_degrees,fpv_doors,false,true),position,rotation_degrees);
        const auto interior=transformed_vertices(mesh.interior,position,rotation_degrees);
        const auto details=transformed_vertices(portal_layer(mesh.details,position,rotation_degrees,fpv_doors),position,rotation_degrees);
        const auto glazing=transformed_vertices(portal_layer(mesh.glazing,position,rotation_degrees,fpv_doors),position,rotation_degrees);
        const auto edges=transformed_vertices(portal_layer(mesh.edges,position,rotation_degrees,fpv_doors,true),position,rotation_degrees);
        const Color line=valid?Color{0.34f,1.00f,0.72f,0.96f}:Color{1.00f,0.38f,0.30f,0.96f};
        const Color faint=valid?Color{0.18f,0.78f,0.56f,0.78f}:Color{0.92f,0.25f,0.20f,0.78f};
        mesh_wireframe::draw_layer(r,foundation,faint,1.25f);
        mesh_wireframe::draw_layer(r,shell,line,1.35f);
        mesh_wireframe::draw_layer(r,interior,faint,1.05f);
        mesh_wireframe::draw_layer(r,details,faint,1.15f);
        mesh_wireframe::draw_layer(r,glazing,{line.r,line.g,line.b,0.62f},1.0f);
        r.draw_lines_3d(edges,line,1.8f);
        for(const auto& access:mesh.entrance_access){
            const auto access_details=transformed_vertices(access.details,position,rotation_degrees);
            const auto access_edges=transformed_vertices(access.edges,position,rotation_degrees);
            mesh_wireframe::draw_layer(r,access_details,faint,1.15f);
            r.draw_lines_3d(access_edges,line,1.6f);
        }
        return;
    }

    if(construction_step<kConstructionSteps){
        const auto visibility=construction_sequence::habitat_visibility(construction_step);
        const auto foundation=transformed_vertices(construction_sequence::reveal_triangles(mesh.foundation,visibility.foundation),position,rotation_degrees);
        const auto shell=transformed_vertices(construction_sequence::reveal_triangles(mesh.shell,visibility.shell),position,rotation_degrees);
        const auto interior=transformed_vertices(construction_sequence::reveal_triangles(mesh.interior,visibility.interior),position,rotation_degrees);
        const auto details=transformed_vertices(construction_sequence::reveal_triangles(mesh.details,visibility.details),position,rotation_degrees);
        const auto glazing=transformed_vertices(construction_sequence::reveal_triangles(mesh.glazing,visibility.glazing),position,rotation_degrees);
        const auto edges=transformed_vertices(construction_sequence::reveal_lines(mesh.edges,visibility.edges),position,rotation_degrees);
        const float boost=selected?1.28f:1.0f;
        // The complete target remains a blue engineering mesh. Every part
        // that has actually been installed replaces that draft with filled,
        // bold yellow construction geometry. The player can therefore read the
        // exact target shape and the completed fraction at the same time.
        const Color blueprint{0.08f,0.36f,0.96f,0.46f};
        const Color installed{1.00f,0.68f,0.12f,0.99f};
        const Color installed_dim{0.96f,0.56f,0.08f,0.96f};
        mesh_wireframe::draw_layer(r,transformed_vertices(mesh.foundation,position,rotation_degrees),blueprint,1.35f*boost);
        mesh_wireframe::draw_layer(r,transformed_vertices(mesh.shell,position,rotation_degrees),blueprint,1.55f*boost);
        mesh_wireframe::draw_layer(r,transformed_vertices(mesh.interior,position,rotation_degrees),blueprint,1.25f*boost);
        mesh_wireframe::draw_layer(r,transformed_vertices(mesh.details,position,rotation_degrees),blueprint,1.30f*boost);
        mesh_wireframe::draw_layer(r,transformed_vertices(mesh.glazing,position,rotation_degrees),{0.10f,0.48f,1.00f,0.40f},1.20f*boost);
        const auto ghost_edges=transformed_vertices(portal_layer(mesh.edges,position,rotation_degrees,fpv_doors,true),position,rotation_degrees);
        if(!ghost_edges.empty()) r.draw_lines_3d(ghost_edges,{0.12f,0.50f,1.00f,0.62f},1.65f*boost);

        mesh_wireframe::draw_layer(r,foundation,installed_dim,1.95f*boost);
        mesh_wireframe::draw_layer(r,shell,installed,2.20f*boost);
        mesh_wireframe::draw_layer(r,interior,installed_dim,1.85f*boost);
        mesh_wireframe::draw_layer(r,details,installed,1.95f*boost);
        mesh_wireframe::draw_layer(r,glazing,{1.00f,0.76f,0.20f,0.94f},1.80f*boost);
        if(!edges.empty()) r.draw_lines_3d(edges,installed,selected?3.45f:2.45f);
        if(construction_step==0){
            const float hx=mesh.footprint_x*0.5f, hz=mesh.footprint_z*0.5f;
            std::vector<Vec3> marker{{-hx,0.03f,-hz},{hx,0.03f,-hz},{hx,0.03f,-hz},{hx,0.03f,hz},{hx,0.03f,hz},{-hx,0.03f,hz},{-hx,0.03f,hz},{-hx,0.03f,-hz}};
            r.draw_lines_3d(transformed_vertices(marker,position,rotation_degrees),blueprint,selected?3.2f:2.4f);
        }
        return;
    }

    auto shell=transformed_vertices(portal_layer(mesh.shell,position,rotation_degrees,fpv_doors),position,rotation_degrees);
    const auto foundation=transformed_vertices(portal_layer(mesh.foundation,position,rotation_degrees,fpv_doors,false,true),position,rotation_degrees);
    const auto interior=transformed_vertices(portal_layer(mesh.interior,position,rotation_degrees,fpv_doors),position,rotation_degrees);
    auto details=transformed_vertices(portal_layer(mesh.details,position,rotation_degrees,fpv_doors),position,rotation_degrees);
    auto glazing=transformed_vertices(portal_layer(mesh.glazing,position,rotation_degrees,fpv_doors),position,rotation_degrees);
    const auto edges=transformed_vertices(portal_layer(mesh.edges,position,rotation_degrees,fpv_doors,true),position,rotation_degrees);
    const Color shell_color{0.24f,0.96f,0.42f,1.0f};
    const Color foundation_color{0.20f,0.84f,0.36f,1.0f};
    const Color interior_color{0.34f,1.00f,0.50f,0.98f};
    const Color detail_color{0.22f,0.92f,0.40f,0.99f};
    const Color glass_color{0.32f,1.00f,0.56f,0.82f};
    const Color edge_color=selected?theme_.accent:Color{0.18f,1.00f,0.38f,1.0f};
    const float selected_boost=selected?1.45f:1.0f;

    // Structures intentionally remain mesh-only in this development phase.
    // Completion is communicated by green color and heavier engineering lines,
    // not by filled/material surfaces or textures.
    mesh_wireframe::draw_layer(r,foundation,foundation_color,2.40f*selected_boost);
    mesh_wireframe::draw_layer(r,interior,interior_color,2.20f*selected_boost);
    mesh_wireframe::draw_layer(r,details,detail_color,2.30f*selected_boost);
    mesh_wireframe::draw_layer(r,glazing,glass_color,2.10f*selected_boost);
    if(habitat_view_mode_==HabitatViewMode::Default){
        mesh_wireframe::draw_layer(r,shell,shell_color,2.65f*selected_boost);
    }else{
        mesh_wireframe::draw_layer(r,shell,{shell_color.r,shell_color.g,shell_color.b,0.24f},1.25f);
    }
    r.draw_lines_3d(edges,edge_color,selected?3.65f:2.90f);
}

void GameApp::render_resource_mesh(Renderer& r,const ResourceMesh& mesh,Vec3 position,float rotation_degrees,bool preview,bool valid,bool selected,float construction_step,const std::vector<CorridorDoor>* fpv_doors) const {
    if(preview){
        const auto body=transformed_vertices(portal_layer(mesh.body,position,rotation_degrees,fpv_doors),position,rotation_degrees);
        const auto foundation=transformed_vertices(portal_layer(mesh.foundation,position,rotation_degrees,fpv_doors,false,true),position,rotation_degrees);
        const auto details=transformed_vertices(portal_layer(mesh.details,position,rotation_degrees,fpv_doors),position,rotation_degrees);
        const auto edges=transformed_vertices(portal_layer(mesh.edges,position,rotation_degrees,fpv_doors,true),position,rotation_degrees);
        const Color line=valid?Color{0.34f,1.00f,0.72f,0.96f}:Color{1.00f,0.38f,0.30f,0.96f};
        const Color faint=valid?Color{0.18f,0.78f,0.56f,0.78f}:Color{0.92f,0.25f,0.20f,0.78f};
        mesh_wireframe::draw_layer(r,foundation,faint,1.20f);
        mesh_wireframe::draw_layer(r,body,line,1.35f);
        mesh_wireframe::draw_layer(r,details,faint,1.10f);
        r.draw_lines_3d(edges,line,1.8f);
        return;
    }

    if(construction_step<kConstructionSteps){
        const auto visibility=construction_sequence::resource_visibility(construction_step);
        const auto foundation=transformed_vertices(construction_sequence::reveal_triangles(mesh.foundation,visibility.foundation),position,rotation_degrees);
        const auto body=transformed_vertices(construction_sequence::reveal_triangles(mesh.body,visibility.body),position,rotation_degrees);
        const auto details=transformed_vertices(construction_sequence::reveal_triangles(mesh.details,visibility.details),position,rotation_degrees);
        const auto edges=transformed_vertices(construction_sequence::reveal_lines(mesh.edges,visibility.edges),position,rotation_degrees);
        const float boost=selected?1.28f:1.0f;
        const Color blueprint{0.08f,0.36f,0.96f,0.46f};
        const Color installed{1.00f,0.68f,0.12f,0.99f};
        const Color installed_dim{0.96f,0.56f,0.08f,0.96f};
        mesh_wireframe::draw_layer(r,transformed_vertices(mesh.foundation,position,rotation_degrees),blueprint,1.35f*boost);
        mesh_wireframe::draw_layer(r,transformed_vertices(mesh.body,position,rotation_degrees),blueprint,1.55f*boost);
        mesh_wireframe::draw_layer(r,transformed_vertices(mesh.details,position,rotation_degrees),blueprint,1.30f*boost);
        const auto ghost_edges=transformed_vertices(portal_layer(mesh.edges,position,rotation_degrees,fpv_doors,true),position,rotation_degrees);
        if(!ghost_edges.empty()) r.draw_lines_3d(ghost_edges,{0.12f,0.50f,1.00f,0.62f},1.65f*boost);

        mesh_wireframe::draw_layer(r,foundation,installed_dim,1.95f*boost);
        mesh_wireframe::draw_layer(r,body,installed,2.20f*boost);
        mesh_wireframe::draw_layer(r,details,installed,1.95f*boost);
        if(!edges.empty()) r.draw_lines_3d(edges,installed,selected?3.45f:2.45f);
        if(construction_step==0){
            const float hx=mesh.footprint_x*0.5f, hz=mesh.footprint_z*0.5f;
            std::vector<Vec3> marker{{-hx,0.03f,-hz},{hx,0.03f,-hz},{hx,0.03f,-hz},{hx,0.03f,hz},{hx,0.03f,hz},{-hx,0.03f,hz},{-hx,0.03f,hz},{-hx,0.03f,-hz}};
            r.draw_lines_3d(transformed_vertices(marker,position,rotation_degrees),blueprint,selected?3.2f:2.4f);
        }
        return;
    }

    auto body=transformed_vertices(portal_layer(mesh.body,position,rotation_degrees,fpv_doors),position,rotation_degrees);
    const auto foundation=transformed_vertices(portal_layer(mesh.foundation,position,rotation_degrees,fpv_doors,false,true),position,rotation_degrees);
    auto details=transformed_vertices(portal_layer(mesh.details,position,rotation_degrees,fpv_doors),position,rotation_degrees);
    const auto edges=transformed_vertices(portal_layer(mesh.edges,position,rotation_degrees,fpv_doors,true),position,rotation_degrees);
    const float boost=selected?1.45f:1.0f;
    mesh_wireframe::draw_layer(r,foundation,{0.20f,0.84f,0.36f,1.0f},2.40f*boost);
    mesh_wireframe::draw_layer(r,body,{0.24f,0.96f,0.42f,1.0f},2.65f*boost);
    mesh_wireframe::draw_layer(r,details,{0.22f,0.92f,0.40f,0.99f},2.35f*boost);
    r.draw_lines_3d(edges,selected?theme_.accent:Color{0.18f,1.00f,0.38f,1.0f},selected?3.65f:2.90f);
}


void GameApp::render_ground_resources(Renderer& r){
    for(std::size_t pile_index=0;pile_index<ground_resource_piles_.size();++pile_index){
        const auto& pile=ground_resource_piles_[pile_index];
        const float half=resource_package_half_width(pile.resource,pile.amount);
        const float h=resource_package_height(pile.resource,pile.amount);
        const bool selected=selection_kind_==SelectionKind::GroundResource &&
            (selected_ground_resource_==(int)pile_index ||
             std::find(selected_ground_resources_.begin(),selected_ground_resources_.end(),(int)pile_index)!=selected_ground_resources_.end());
        draw_resource_box(r,pile.position,half,h,pile.resource,selected);
    }
}

void GameApp::render_resources(Renderer& r){
    for(size_t i=0;i<placed_resources_.size();++i){
        const auto& instance=placed_resources_[i];
        const bool selected=selection_kind_==SelectionKind::Resource && selected_resource_==(int)i;
        const auto& mesh=resource_models_.mesh(instance);
        std::vector<CorridorDoor> fpv_doors;
        const std::vector<CorridorDoor>* fpv_ptr=nullptr;
        if(instance.kind==ResourceKind::StorageDome && instance.construction.complete()){
            fpv_doors=storage_dome_doors(i);
            fpv_ptr=&fpv_doors;
        }
        render_resource_mesh(r,mesh,instance.position,instance.rotation_degrees,false,true,selected,instance.construction.progress()*(float)kConstructionSteps,fpv_ptr);
        if(fpv_ptr) for(const auto& door:fpv_doors) draw_sliding_door(r,door,first_person_door_open_fraction(door.wall_position));

        if(instance.kind!=ResourceKind::StorageDome || !instance.construction.complete() || instance.stored_boxes.empty()) continue;

        // Every stored resource remains a physical human-portable package. The
        // same deterministic pallet pose is used by FPV picking, so the box a
        // player sees is exactly the box that can be grabbed.
        for(std::size_t bi=0;bi<instance.stored_boxes.size();++bi){
            Vec3 base{}; float half=0.0f,box_h=0.0f;
            stored_resource_box_pose(instance,mesh,bi,base,half,box_h);
            draw_resource_box(r,base,half,box_h,instance.stored_boxes[bi].resource,false);
        }
    }
}

void GameApp::render_utilities(Renderer& r){
    const auto& links=utility_network_.connections();
    for(size_t i=0;i<links.size();++i){
        const auto& link=links[i];
        const bool selected=selection_kind_==SelectionKind::Utility && selected_utility_==(int)i;
        const float boost=selected?1.55f:1.0f;

        if(!link.construction.complete()){
            const float fraction=link.construction.progress();
            const Color build_main{1.00f,0.68f,0.12f,0.99f};
            const Color build_detail{0.96f,0.56f,0.08f,0.96f};
            const Color ghost{0.10f,0.40f,0.90f,0.46f};
            mesh_wireframe::draw_layer(r,link.mesh.shell,ghost,1.50f*boost);
            mesh_wireframe::draw_layer(r,link.mesh.details,ghost,1.25f*boost);
            if(!link.mesh.edges.empty()) r.draw_lines_3d(link.mesh.edges,{0.14f,0.54f,1.00f,0.58f},1.65f*boost);
            if(fraction<=0.0001f){
                r.draw_lines_3d(construction_path_lines(link.path),Color{0.12f,0.58f,1.00f,0.92f},selected?3.2f:2.3f);
            }else{
                const auto shell=construction_sequence::reveal_triangles(link.mesh.shell,fraction);
                const auto details=construction_sequence::reveal_triangles(link.mesh.details,fraction);
                const auto edges=construction_sequence::reveal_lines(link.mesh.edges,fraction);
                                mesh_wireframe::draw_layer(r,shell,build_main,2.05f*boost);
                mesh_wireframe::draw_layer(r,details,build_detail,1.80f*boost);
                if(!edges.empty()) r.draw_lines_3d(edges,build_main,selected?3.35f:2.30f);
            }
            continue;
        }

        const Color shell{0.24f,0.96f,0.42f,1.0f};
        const Color details{0.22f,0.92f,0.40f,0.99f};
        mesh_wireframe::draw_layer(r,link.mesh.shell,shell,2.60f*boost);
        mesh_wireframe::draw_layer(r,link.mesh.details,details,2.35f*boost);
        r.draw_lines_3d(link.mesh.edges,selected?theme_.accent:Color{0.18f,1.00f,0.38f,1.0f},selected?3.60f:2.85f);
    }
}


void GameApp::render_walkways(Renderer& r){
    const auto& links=walkway_network_.connections();
    for(size_t i=0;i<links.size();++i){
        const auto& w=links[i];
        const bool selected=selection_kind_==SelectionKind::Walkway && selected_walkway_==(int)i;
        const float boost=selected?1.55f:1.0f;
        if(!w.construction.complete()){
            const float fraction=w.construction.progress();
            const Color build_main{1.00f,0.68f,0.12f,0.99f};
            const Color build_detail{0.96f,0.56f,0.08f,0.96f};
            const Color ghost{0.10f,0.40f,0.90f,0.46f};
            mesh_wireframe::draw_layer(r,w.mesh.deck,ghost,1.50f*boost);
            mesh_wireframe::draw_layer(r,w.mesh.details,ghost,1.25f*boost);
            if(!w.mesh.edges.empty()) r.draw_lines_3d(w.mesh.edges,{0.14f,0.54f,1.00f,0.58f},1.65f*boost);
            if(fraction<=0.0001f){
                r.draw_lines_3d(construction_path_lines(w.path),Color{0.12f,0.58f,1.00f,0.92f},selected?3.2f:2.3f);
            }else{
                const auto deck=construction_sequence::reveal_triangles(w.mesh.deck,fraction);
                const auto details=construction_sequence::reveal_triangles(w.mesh.details,fraction);
                const auto edges=construction_sequence::reveal_lines(w.mesh.edges,fraction);
                        mesh_wireframe::draw_layer(r,deck,build_main,2.05f*boost);
                mesh_wireframe::draw_layer(r,details,build_detail,1.80f*boost);
                if(!edges.empty()) r.draw_lines_3d(edges,build_main,selected?3.35f:2.30f);
            }
            continue;
        }
        mesh_wireframe::draw_layer(r,w.mesh.deck,{0.24f,0.96f,0.42f,1.0f},2.60f*boost);
        mesh_wireframe::draw_layer(r,w.mesh.details,{0.22f,0.92f,0.40f,0.99f},2.35f*boost);
        r.draw_lines_3d(w.mesh.edges,selected?theme_.accent:Color{0.18f,1.00f,0.38f,1.0f},selected?3.60f:2.85f);
    }
}

void GameApp::render_corridors(Renderer& r){
    const auto& corridors=corridor_network_.connections();
    for(size_t i=0;i<corridors.size();++i){
        const auto& connection=corridors[i];
        const bool selected=selection_kind_==SelectionKind::Corridor && selected_corridor_==(int)i;
        const bool link_source=corridor_link_source_==(int)i;
        const Color edge_color=(selected||link_source)?theme_.accent:Color{0.18f,1.00f,0.38f,1.0f};
        const float boost=(selected||link_source)?1.55f:1.0f;

        if(!connection.construction.complete()){
            const float fraction=connection.construction.progress();
            const Color build_main{1.00f,0.68f,0.12f,0.99f};
            const Color build_detail{0.96f,0.56f,0.08f,0.96f};
            const Color ghost{0.10f,0.40f,0.90f,0.46f};
            mesh_wireframe::draw_layer(r,connection.mesh.shell,ghost,1.55f*boost);
            mesh_wireframe::draw_layer(r,connection.mesh.details,ghost,1.30f*boost);
            if(!connection.mesh.edges.empty()) r.draw_lines_3d(connection.mesh.edges,{0.14f,0.54f,1.00f,0.58f},1.70f*boost);
            if(fraction<=0.0001f){
                r.draw_lines_3d(construction_path_lines(connection.path),Color{0.12f,0.58f,1.00f,0.92f},(selected||link_source)?3.3f:2.4f);
            }else{
                const auto shell=construction_sequence::reveal_triangles(connection.mesh.shell,fraction);
                const auto details=construction_sequence::reveal_triangles(connection.mesh.details,fraction);
                const auto edges=construction_sequence::reveal_lines(connection.mesh.edges,fraction);
                                mesh_wireframe::draw_layer(r,details,build_detail,1.80f*boost);
                mesh_wireframe::draw_layer(r,shell,build_main,2.05f*boost);
                if(!edges.empty()) r.draw_lines_3d(edges,build_main,(selected||link_source)?3.45f:2.35f);
            }
            continue;
        }

        const Color shell_color{0.24f,0.96f,0.42f,1.0f};
        const Color detail_color{0.22f,0.92f,0.40f,0.99f};
        // Open corridor endpoints are permanent sealed pressure bulkheads.
        // Exterior access is provided only by a connected Air Lock habitat, so
        // corridor meshes never carve/open a door at an exposed endpoint.
        mesh_wireframe::draw_layer(r,connection.mesh.details,detail_color,2.35f*boost);
        if(habitat_view_mode_==HabitatViewMode::Default || first_person_mode_==FirstPersonMode::Active){
            mesh_wireframe::draw_layer(r,connection.mesh.shell,shell_color,2.65f*boost);
        }else{
            mesh_wireframe::draw_layer(r,connection.mesh.shell,{shell_color.r,shell_color.g,shell_color.b,0.24f},1.25f);
        }
        r.draw_lines_3d(connection.mesh.edges,edge_color,(selected||link_source)?3.65f:2.90f);
    }
}


void GameApp::render_habitats(Renderer& r){
    for(size_t i=0;i<placed_habitats_.size();++i){
        const auto& instance=placed_habitats_[i];
        const auto& mesh=habitat_models_.mesh(instance);
        const bool selected=selection_kind_==SelectionKind::Habitat && selected_habitat_==(int)i;
        std::vector<CorridorDoor> fpv_doors;
        const std::vector<CorridorDoor>* fpv_ptr=nullptr;
        if(instance.construction.complete()){
            fpv_doors=habitat_doors(i);
            fpv_ptr=&fpv_doors;
        }
        render_habitat_mesh(r,mesh,instance.position,instance.rotation_degrees,false,true,selected,instance.construction.progress()*(float)kConstructionSteps,fpv_ptr);
        if(fpv_ptr) for(const auto& door:fpv_doors) draw_sliding_door(r,door,first_person_door_open_fraction(door.wall_position));

        // Exterior stairs/ramps exist only on the dedicated Air Lock and only
        // for an authored hatch that is currently the surface side of a
        // completed pressure network.  Ordinary structures never expose unused
        // entrances directly to the lunar surface.
        if(instance.construction.complete()) for(size_t entrance_index=0;entrance_index<mesh.entrance_access.size();++entrance_index){
            if(!habitat_exterior_access_enabled(i,entrance_index)) continue;
            const auto& access=mesh.entrance_access[entrance_index];
            if(entrance_access_hits_corridor(access,instance.position,instance.rotation_degrees,corridor_network_)) continue;
            const float access_fraction=instance.construction.complete()?1.0f:0.5f;
            const auto details=transformed_vertices(construction_sequence::reveal_triangles(access.details,access_fraction),instance.position,instance.rotation_degrees);
            const auto edges=transformed_vertices(construction_sequence::reveal_lines(access.edges,instance.construction.complete()?1.0f:0.0f),instance.position,instance.rotation_degrees);
            const Color access_color=instance.construction.complete()?Color{0.24f,0.96f,0.42f,1.0f}:Color{1.00f,0.68f,0.12f,0.99f};
            mesh_wireframe::draw_layer(r,details,access_color,instance.construction.complete()?2.45f:2.0f);
            if(!edges.empty()){
                const Color ec=selected?theme_.accent:Color{0.08f,0.11f,0.13f,1.0f};
                r.draw_lines_3d(edges,ec,selected?3.35f:(instance.construction.complete()?2.55f:2.25f));
            }
        }
    }
}

} // namespace game
