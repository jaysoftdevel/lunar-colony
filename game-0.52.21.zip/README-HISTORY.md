## v0.50.17 — Physical cryogenic tank sizing and lunar-return refueling

- Replaces gameplay-scale hydrogen storage (400/800 kg) with **2,000 kg SMALL** and **8,000 kg STANDARD** LH2. The standard tank is a **3.35 m-radius sphere** (~157.5 m³ gross, ~8.4 t possible at 71 kg/m³ and 75% usable fill). The small tank scales all 3 axes by **0.63**, giving ~one quarter the usable volume. Its construction footprint and visual mesh now follow the spherical vessel.
- Models a **Moon-surface departure and trans-Earth transfer** using a 3,000 m/s delta-v budget (~1.92 km/s ascent plus ~0.975 km/s trans-Earth insertion/correction and allowance), 450 s LH2/LOX vacuum Isp, and 6:1 LOX:H2 mass ratio. Rocket dry+return payload mass: 30 t; small return lander: 8 t. Rocket fueling allocates **4,200 kg H2** and explicitly displays **25,200 kg LOX needed**; lander allocates **1,150 kg H2** and displays **6,900 kg LOX needed**. The figures are derived from the ideal rocket equation, rounded up to 50 kg increments.
- Existing Stage-2 hydrogen handling still transfers **actual mass** from completed, powered, connected tanks, with no duplication, no double-fill, save/load support, and fuel-cell consumption of the same tank inventory. Old schema-31 save files retain their original kilograms (no free refueling).
- **Scope/limitation:** This models LH2 storage and LH2 allocation, *not* rocket liftoff. Liquid oxygen storage, liquefaction, loading, boil-off, and return flight are not yet implemented; hydrogen **alone is not sufficient for launch**. Mars and Earth departures demand different delta-v/mass models.
- Technical references: NASA 1972 *Extraterrestrial Consumables Production and Utilization*, NASA CR 1990 *Assured Crew Return Vehicle* delta-v estimates, and NASA SLS core-stage cryogenic propellant facts. See `VALIDATION.md` for sizing calculation.

## v0.50.16 — Lunar Hydrogen Storage Tank and pad fueling

- **Stages 2 and 3:** New outdoor **Hydrogen Storage Tank** in the Structure build catalog (SMALL or STANDARD), with a detailed 3D twin cryogenic vessel mesh, insulation collars, gauges, protected piping, and a construction material recipe. Capacities: **400 kg** small / **800 kg** standard, gameplay-scale mass values.
- A connected, completed hydrogen tank collects H2 from the oxygen generator's electrolysis by-product. Tank hydrogen is part of the local supply-channel component (not global inventory); it can also feed an existing hydrogen electricity generator. Disconnected tanks never receive/offer H2.
- Selecting a completed **Landing Pad** now displays separate **rocket (80 kg H2)** and **lander (30 kg H2)** fuel allocations with **FUEL ROCKET** and **FUEL LANDER** buttons. Transfer subtracts actual kilograms from a connected, completed hydrogen tank. Fueling requires network power. Neither button can overfill or duplicate hydrogen.
- Selecting a Hydrogen Storage Tank displays its capacity, fill percentage and usage. A tank below 10% gets the normal low-stock warning. Landing-pad fuel allocations and tank contents survive save/load.
- **Save schema 31** appends the new resource kind without changing older structure IDs and serializes allocated vehicle fuel per landing pad. Schema-30 and earlier saves load with empty vehicle fuel allocations; other mechanics remain compatible.
- This adds physical storage and fueled vehicle allocations, **not** a full surface-rocket flight model. It does not add an oxidizer inventory or a takeoff simulation. The Stage-1 campaign rocket/lander mission remains separate.


## v0.50.15 — Additional contracts and funded lunar deployment

- Expanded Stage-1 contract portfolio to **32 unique contracts**: 31 one-time commercial projects plus the one-time lunar cargo sponsorship. 20 new projects start at early research tiers and develop through launch, engineering, robotics, exploration, water, habitats and full base deployment. All completed projects remain closed.
- The 31 commercial contracts pay **EUR 94.35M** total in signing advances and standard delivery payments, *before* first-customer bonuses and investor awards. Lunar launch sponsorship is excluded: its final installment is not paid until after launch.
- All 16 tech nodes cost **EUR 21.85M** at full undiscounted pricing. Even the most costly rocket + lander pair costs EUR 37M, leaving over EUR 35M of base commercial funding for the Stage-2 minimum payload, without relying on any future launch payout.
- Contract Office now shows a **program-cost versus total contract-funding** forecast using the actual Stage-2 minimum manifest and the most expensive rocket/lander combination.
- **Save schema 30** expands the contract history from 12 to 32 records and remaps old lunar sponsorship slot 11 to the final slot. Existing contract IDs 0..10 retain their completion and active states. Stage 2 and Stage 3 unchanged.

## v0.50.14 — Contract research requirement checklist

- Each Stage-1 customer contract now shows **all** research needed to accept it, including the direct contract requirements and their recursively required technology prerequisites.
- Unresearched items are shown in **red** with `MISSING`; already unlocked technologies are shown in **green** with `RESEARCHED`. `DIRECT` and `PREREQUISITE` labels distinguish contract gates from supporting research.
- The contract brief includes an `N / M COMPLETE` count. Projects with no technology prerequisite explicitly say that no research is required. At high UI zoom, arrow controls page through all dependencies without obscuring the payout or contract buttons.
- Research state refreshes immediately as new technologies unlock. Contract availability, payments, research costs, Stage-2/3 behavior and existing save files are unchanged (schema 29).

## v0.50.13 — Consistent Stage-1 UI and double-click actions

- A selected section is highlighted in the bottom navigation, and NEXT STEP is more prominent. The Contract Office gives more width to the project brief, has clearer primary-action styling and explains the selection/double-click interaction. The Research Tree inspector has clearer status highlighting; Mission Prep includes **GO TO NEXT FACILITY** when space permits.
- Contract cards: **single click selects**, **double-click accepts or delivers** if permitted. Active jobs can double-click to advance to their next report; completed jobs remain permanently closed.
- Research cards: **single click inspects**, **double-click buys/unlocks** only when prerequisites and funds permit. Research is never charged twice. The standard action buttons remain available.
- Mission financing and launching still require the explicit facility action buttons. Click the current gate to navigate to its responsible facility; double-clicking a timeline card is not a launch shortcut.
- Stage 2/3 are unchanged; save schema remains **29**. See `STAGE1-UI-CONTROLS.md`.

## v0.50.12 — One-time contracts and persistent Stage-1 mission planning

- Every customer contract can only be accepted and delivered **once per campaign**. Completed contracts remain visible for reference but cannot be replayed. Their payments and research discounts remain earned.
- Contract Office states are color-coded: **green** completed/closed, **gold** ready for delivery, **blue** active, **cyan** available, and **gray** locked. Status text remains visible for accessibility.
- Save compatibility: pre-v0.50.12 saves containing previously delivered but replayable contracts migrate those contracts to Completed using the existing `completed_count` history. No save-schema change (schema 29).
- **Mission Prep** and **Resume Mission** now return to the previously selected facility and retain the rocket, lander, manifest, paid status and preparation gate. The mission overview offers **Continue at Required Facility**; the current workflow tile is also clickable. Opening the company site or contracts does not restart mission preparation.
- This version changes Stage 1 only. Stage 2/3 simulation and free-play starter supplies are unchanged.

## v0.50.11 — One-time lunar launch and automatic Stage-2 deployment

Stage 1 has **one lunar mission per campaign**. Once every facility gate is
complete, **LAUNCH & DEPLOY TO MOON** begins Stage 2 immediately. Its starting
resource depot and shared material inventory are populated **exactly** from the
Stage-1 paid cargo manifest (iron, copper, silicon, plastic, aluminum, water,
food and medical supplies). The game spawns one constructor and one carrier
robot on a fresh 128 × 128 lunar playfield, ready to construct the base.

Mission funding, cargo loading, launch and lunar-customer delivery payment
cannot be repeated. Ordinary repeatable commercial **contracts** are still
available in Stage 1 as a funding safety net; they are not repeatable lunar
missions. Career versus Free Play mode and the complete technology/contract
history remain saved, and direct Free Play Stage-2 starts continue to receive
the standard starter reserve rather than an invented campaign shipment.

Save schema remains **29**. A previously completed, paid Stage-1 mission saved
by an older version automatically deploys into Stage 2 upon loading. Stage-3
and normal Stage-2 construction/navigation are unaffected.

---

## v0.50.9 — Contracts now fund and validate the entire Stage-1 campaign

Stage 1 has a **customer-project board** with an individually selectable project brief, deliverable, signing advance, final delivery payment, exact prerequisite research, related technology, work progress and a direct Tech Tree/Mission link. The board puts ready-to-submit projects ahead of active, available and locked opportunities, and highlights the Program & Contracts Office when a new Career needs its first contract or has reports ready to deliver.

Commercial projects now advance to **ready for customer delivery** when their work time is complete; the final payment is only credited when the player submits the deliverable. Completing a technical project permanently discounts the related research by 15% (maximum 35% from distinct first-time reports); repeat delivery is still a funding source but does not stack research discounts. The one-time Lunar Cargo Delivery contract now settles on the **actual mission launch**, not a timer, and must be accepted before launch to receive its sponsorship. The original mission funding, minimum lunar cargo, facility gates and existing Stage-2/3 simulation are preserved.

Begin with the highlighted Program & Contracts Office and see **[STAGE1-CAMPAIGN-GUIDE.md](STAGE1-CAMPAIGN-GUIDE.md)** for the game loop, recommended first contract and facility roles. Save schema remains **29**; there are no new persistent fields, and older contract progress/histories are compatible.

---

## v0.50.8 — Connected, navigable Stage-1 research network

The Stage-1 Tech Tree has been visually redesigned around a dark space-themed
research map with larger, illuminated technology cards, category badges, bright
blue/green prerequisite connections, explicit directional arrows, and distinct
**RESEARCHED / READY TO FUND / LOCKED** states. The full 16-node DAG and all
existing research costs, prerequisites and unlock logic are unchanged.

Use the mouse wheel to zoom toward the cursor, drag empty canvas with the left
button (or drag anywhere with right/middle) to pan, **FIT ALL** to overview the
whole dependency network, and **FOCUS** to center the selected technology.
Click a technology to inspect its full description, prerequisite list, cost,
and a context-sensitive **UNLOCK TECHNOLOGY** button in the bottom pane.
Technology-map navigation is transient UI state; the saved research and
mission-planning format remains schema 29 with no save migration.

The Stage-2/Stage-3 simulation, Stage-1 campus, company economy, contract and
mission-preparation rules remain unchanged. Rendering uses the existing shared
2D drawing API so the research UI works with both OpenGL and Direct3D renderers.

---

## v0.50.7 — Stable Stage-1 orbit and high-resolution campus materials

Stage 1 now renders as a daylight coastal launch-campus environment with native
1024 x 1024 tileable textures for 9 surface classes, mipmapped sampling, and
sunlit industrial facades and glass. The materials are **procedurally generated
at startup**, not photographic scans. New modeling includes coastal dune slopes,
parking/service vehicles, HVAC equipment, fuel/conduit infrastructure, road
signs, security lighting and operations-yard details. Every facility is still
clickable, with mission workflow unchanged.

**Rotation flicker mitigation:** Stage 1 uses a dedicated camera projection with
near/far planes scaled to camera distance, dramatically improving depth
precision for road paint, service aprons and near-coplanar terrain. Coplanar
campus silhouette wire edges are omitted, and textured surfaces use GPU mipmaps
when supported (bilinear fallback otherwise). This does not alter Stage-2/3
camera projection or the gameplay rules.

**Controls:** mouse wheel zoom; middle-button drag orbit; right-button drag pan;
W/A/S/D move. The starting camera uses a 47-degree oblique view.

**Graphics:** enhanced texture/lighting path is Linux OpenGL. The Windows
Direct3D fallback retains solid colors; full Windows textured/PBR parity and
photogrammetry-quality building models are not part of this release. A software
GL diagnostic mode is available only with `GAME_ALLOW_SOFTWARE_GL=1`;
hardware acceleration is still required by default.

---

## v0.50.6 — Career / Free Play + launch-campus environment

**New Game** begins with Career/Campaign (always Stage 1) or Free Play (choose Stages 1, 2, or 3). Both use the same gameplay systems; game mode is saved independently of the chosen stage. Existing saves from older schemas default to Free Play. Career begins in Stage 1, but automatic progression into Stage 2 is not yet implemented.

The New Game and Main Menu screens have a new layered night-sky/launch-center visual theme, a prominent mode selector, and layouts tested across the existing resolution and zoom matrix. Stage 1 always uses a fixed 128 × 128 planning campus and never presents a size picker; Stage 2 retains the resizable playfield and robot/debug options. Stage 3 keeps its fixed completed-base starting template.

Stage 1 uses a new coastal company-campus landscape: procedural high-frequency grass, sand, tarmac, concrete, water and industrial roofing materials; individual building façade lighting, projected ground shadows, brighter landscaping, parking, roads, trees, service equipment, and more recognizable launch/test/integration infrastructure. The OpenGL backend renders the fine material pattern in a fragment shader, so details remain sharp while zooming. Other backends use an intentionally compatible untextured color fallback; this is not a physically based global-illumination system or a true GPU shadow-map. The orbitable camera opens closer at a 55-degree elevation with a 38-degree azimuth and retains wheel zoom, MMB rotate, RMB drag pan and WASD translation. Facility click routing and the Stage-1 mission workflow are unchanged.

Save schema **29** persists the Career/Free Play distinction. Linux Release build and all UI, company-site, mission-workflow and targeted colony regressions pass. The update package contains source changes only and never runs a build from `apply.sh`.

# Game 0.42.2 — Linux + Windows shared source

This is a single cross-platform game source tree. Linux uses X11/OpenGL and Windows 11 uses Win32/Direct3D 12; gameplay and simulation code are shared.

## Quick start

Linux: `./dev.sh build Release` then `./dev.sh run`

Windows: `dev.bat build Release` then `dev.bat run`

See `CROSS-PLATFORM-DEVELOPMENT.md` and `DEPENDENCIES.md` for the mirrored development workflow and prerequisites.

---

# Game workspace

**Baseline release: 0.30.0** — rendering, pressure-network topology, crew scale, movement and buildable geometry are frozen here as the gameplay-development baseline.

Native C++20 prototype with a strict split between the reusable engine (`engine/`) and game implementation (`game/`).

## Windows 11 / Direct3D 12 port

This source tree now has a native Windows backend in addition to the original Linux backend. Windows uses Win32 + Direct3D 12/DXGI and probes hardware feature levels up to 12_2; Linux keeps X11 + OpenGL/GLX. Gameplay and save-game code are shared. See `README-WINDOWS.md` for Windows dependencies, build commands, compatibility notes and the exact list of Linux implementation details replaced on Windows.

## Local Linux build

Required tools/libraries: a C++20 compiler, CMake, X11 development headers and a working OpenGL/GLX runtime.

Debian/Ubuntu example:

```bash
./install-deps.sh
./build.sh Release
./run.sh
```

Linux builds are incremental under `build/linux/`. Use `./build.sh Release --clean` or `./dev.sh rebuild Release` for a clean rebuild. Windows uses the independent `build/windows/` tree, so both native configurations can be developed from the same checkout without CMake-cache collisions. No prebuilt executable is stored in the project workspace.

## Current controls

- Mouse wheel: zoom relative to the current view center.
- Middle mouse drag left/right: rotate around the current view center.
- Middle mouse drag up/down: tilt from 0 to 90 degrees.
- Right mouse drag: pan relative to camera orientation and zoom.
- Left click: menus and build-object selection.
- Escape: return to the main menu.

The game starts fullscreen. The bottom build palette is data-driven through `BuildCatalog`, and the top status bar receives its prototype values from `ColonyStatus` so both can be replaced by later simulation systems without changing the renderer.

## Structure modules
Crew-accessible habitats and corridors share a common structural access contract. Every habitat keeps exterior and interior geometry in separate modules, while its module registration declares the authoritative POV deck height and access behavior. Corridor shell and walking-deck generation follow the same outer/inner split.

## Baseline physical/visual contract
- The canonical astronaut is 80% of the earlier prototype scale; eye height, body radius and clearance tests use the same shared constants.
- Habitats and resource structures receive shared maintainability hardware plus their type-specific equipment.
- Corridors use continuous pressure shells, reinforced ribs, internal decks, service trunks, double dock seals and structural sealed-end bulkheads.
- Exterior walkways are non-pressurised and can meet the colony pressure system only at a connected Air Lock.
- Supply channels include structural supports, electrical/data routing and water-service hardware.
- World construction geometry is mesh-only in the current development phase: blue target mesh, yellow installed mesh and substantially bolder green mesh at completion. No structure textures or filled surfaces are emitted yet.

## v0.42.2 robot path-negotiation performance

Behaviour-preserving optimisation of rover navigation, targeting frame stutter whenever several robots were active:

- Rover clearance queries read a per-tick structure snapshot (precomputed rotations, bounds of unfinished targets, wall triangles cached per construction stage) instead of rescanning every building and mesh for every sample.
- Swept structure/obstacle tests run once per segment; contract arbitration skips contracts that are not spatially close.
- Pull-out and stationary-detour candidate searches run across the worker pool and select the same winner as the serial scan.
- Light planner batches run on the game thread; `eng::TaskPool::parallel_for` uses one shared job object instead of per-helper futures.
- Heavy route-search concurrency now defaults to at most two lanes regardless of core count (`GAME_ROUTE_SEARCH_LANES` still overrides). Three or more simultaneous searches made the construction fleet livelock on hosts with six or more lanes.

Measured with the headless `navigation_regression` suite: the late-corridor scenario dropped from 1.04 ms mean / 33.6 ms worst frame to 0.22 / 2.8 ms, and the full construction run now completes on every host size.

## v0.42.0 cross-platform Windows 11 / Linux workspace

- Unified Linux and Windows development in one source tree while retaining the complete v0.41.8 gameplay baseline.
- Linux uses X11 + OpenGL/GLX; Windows 11 uses Win32 + Raw Input + Direct3D 12/DXGI.
- Added matched `.sh` and `.bat` configure/build/run/test/clean/dev workflows with isolated `build/linux` and `build/windows` trees.
- Added Windows path/runtime compatibility for executable-relative saves/debug data and Windows CPU topology detection.
- Added cross-platform CMake presets, dependency documentation, platform matrix, and Windows build/status documentation.
- Save schema and gameplay behavior remain compatible with the v0.41.8 baseline.

## v0.41.8 paid storage gate extensions and mesh doors

Select a storage dome blueprint or completed dome and choose **ADD GATE** to plan up to two additional loading gates (three total). Each upgrade shows its material cost and construction progress in the storage panel, receives actual resource deliveries, and is assembled by builders once its parent dome is complete. The original gate remains included in the dome cost. Each added gate currently requires 78 kg of construction materials across six stages.

Extra gates use free faces with clear loading aprons. Their aprons are reserved from planning onward against structures, crew corridors and walkways; occupied corridor faces cannot be replaced. Robots select independent completed loading stations for simultaneous deposits and withdrawals. Unfinished gates stay unavailable. Removing a dome also removes and recovers its upgrades. Save schema 16 retains parent links and construction state and reads older saves.

Pressure doors and storage gates now follow the native mesh display: blue planned geometry, yellow installed construction and green completed meshes. Sliding leaves, perimeter seals and sealed transfer buffers remain physical geometry. Cargo modules replace the unused crew-port furniture at their faces so retracted gates have clear openings.

## v0.41.7 outdoor robot workshop

Build **Robot Workshop** from the Structures palette. Each workshop has four independent robot service bays, a boarding ramp and an automatic sliding gate. After construction completes, idle robots return to assigned bays inside; new construction/delivery work takes priority and dispatches them again. Docked service restores mechanical condition. Build additional workshops for fleets larger than four robots.

The placement preview marks the ramp approach and waiting area in amber. The entire rotated area must remain inside the playfield and clear of blocking structures, pallets, corridors and walkways. Placement also checks a static route to the fleet. Later construction placement protects that approach. Robot collision and floor queries share the exact hollow workshop/ramp geometry. The workshop is an outdoor robot structure and does not accept pressure-corridor connections.

## v0.41.6 fixed storage gates and hermetic sliding doors

Storage domes include a dedicated robot loading gate with a marked approach bay. Robots put in and take out cargo at a completed gate, queuing off-axis when occupied. Corridors cannot attach to gates or cross their reserved loading areas. Each gate orientation is fixed; older saves retain their installed corridors and receive the original gate on an unused face.

Completed corridor-to-structure connections use solid paired sliding pressure doors with perimeter gaskets and overlapping centre seals. They open for a nearby POV user, wait while the doorway is occupied, and close afterward. Closed and partly open leaves block movement. Air Lock doors interlock, and the storage loading buffer remains sealed from crew interiors. Save schema 14 retains older-save support.

## v0.41.5 close-range carrier blueprint drop-offs

CR-01 carriers delivering to habitat/resource blueprints can now approach much closer to the target structure side. The delivery-apron picker no longer enforces the same conservative own-target footprint clearance used for unrelated structures while that target is still incomplete, and the selected apron offset for incomplete targets is reduced. This keeps unloading visibly near the blueprint so staged resource boxes appear where the carrier is actually servicing, while completed structures and non-target obstacles retain the wider safety clearances.

## v0.41.4 planner peak-load smoothing

Large multi-rover collision-avoidance replans could still create frame-time spikes when many robots refreshed route/proposal work in the same safety tick. Planner refresh now uses deterministic per-rover phase offsets, a bounded per-tick planner-job budget, and a bounded default lane count for concurrent heavy global route searches. The shared 10 ms contract authority remains unchanged and continues to certify every accepted movement.

Operational override:

- `GAME_ROUTE_SEARCH_LANES=<n>` sets concurrent heavy global route-search lanes explicitly.

## v0.41.3 deterministic head-on rover evasion

When two active rovers approach each other head-on on a near-centerline closing path, local reciprocal steering now applies an explicit right-side evasion bias from each rover's own frame of reference. This makes opposing encounters deterministic and symmetric: both robots select their own right-hand pass direction before motion-contract arbitration, reducing left/right indecision and repeated stop-brake micro-cycles in narrow lanes.

## v0.41.2 host-resource throughput defaults

Runtime defaults are now intentionally aggressive for host utilization. CPU planning already scales across all visible logical CPUs via the persistent task pool. GPU presentation now explicitly requests swap interval 0 by default (VSync off) so render throughput is not implicitly refresh-capped by driver defaults. The main loop no longer applies an unconditional 1 ms per-frame sleep, allowing update/render to run at full available host throughput.

Operational controls remain available for diagnostics and thermals:

- `GAME_CPU_LANES=<n>` caps runtime CPU lanes.
- `GAME_VSYNC=1` enables synchronized present (`0` or unset keeps uncapped present).
- `GAME_FRAME_LIMIT_FPS=<n>` applies an explicit frame-rate cap.

### 0.31.2
BR-02 builders use chassis-sized collision avoidance around structures, resource packages and fleet mates. Construction work is visibly animated through pick-up, put-down, material application, welding and build-up; stages advance only after the resource-backed animation sequence completes.

## 0.31.3 construction presentation
Incomplete habitats, resource facilities, corridors, supply channels and walkways retain a faint full final-mesh outline while the built portions are revealed. BR-02 builders use acceleration/turn-limited steering with stand-off arrival, move around the target during assembly, and use staged manipulator sequences for pickup, placement, material application, welding and build-up.
## 0.31.4 carrier logistics and simulation speed
Construction blueprints no longer reserve their complete footprint as robot collision. BR-02/CR-01 motion is blocked only by geometry that has actually been erected at the current construction stage, allowing robots to cross future/unbuilt volume while naturally routing around walls, machinery and hull segments as they appear. New games include one CR-01 Carrier Bot in addition to the selected 1-6 BR-02 constructors. CR-01 prioritizes material delivery to waiting construction sites and automatically consolidates loose resource pallets into a completed Storage Dome, which becomes the preferred supply depot. Constructors remain responsible for building and self-haul only when carrier support cannot satisfy a site. The bottom bar provides NORMAL 1X, QUICK 2X and FAST 4X simulation speed controls; POV/camera response remains real-time.


## v0.31.5 construction safety
Construction steps use a pre-commit fleet evacuation gate: blueprint space remains traversable until its mesh exists, but a new stage cannot appear around a robot. Before walls/body/network geometry is revealed, affected robots are moved to a safe exterior position and the step commits only after the fleet is clear.

## v0.31.6 fleet routing

New Game independently selects 1-6 BR-02 builders and 1-6 CR-01 carriers. Carrier bots specialize in hauling resources from ground piles or the Storage Dome depot to active construction sites; builders remain construction-first but can self-haul when a site is starved. Robot trips are planned before motion using collision-aware shortest-path search, line-of-sight smoothing and fleet route reservations, so conflicting routes wait/replan instead of crossing.

## v0.31.7 cooperative robot crews
Multiple BR-02 builders can now share one construction target and work around it in parallel while one coordinator owns the authoritative site buffer and stage commit. Multiple CR-01 carriers can feed the same site when the remaining material mass requires more than one payload, without duplicating already-reserved deliveries. Builders still self-haul if the shared site remains starved. CR-01 transit speed is 10% above BR-02 (2.42 m/s vs 2.20 m/s).

## v0.31.9 synchronized carrier logistics and robot inspection
CR-01 carriers now derive every trip from the shared construction-site material ledger: required mass minus delivered mass minus fleet-reserved/in-transit mass. Each trip reserves one concrete material and kilogram amount before movement, preventing duplicate hauling while allowing several carriers to support the same site in parallel. Ground resource stacks expose collision-free service positions and the starter depot uses robot-accessible service spacing, so a valid reservation always maps to a reachable pickup. BR-02 builders continue to self-haul only the unreserved deficit when carrier logistics cannot satisfy a site.

Every BR-02/CR-01 is individually selectable in the world. The robot inspector shows role, live state/action, condition, movement/route state, construction target, cargo by material and kilograms, exact logistics reservation, and the target site's delivered / reserved-in-transit / still-unassigned material ledger.


## v0.31.9 construction tracking
Incomplete habitats, resource structures, corridors, supply channels and walkways keep a projected status frame visible until completion. Each frame shows build progress and remaining material demand after delivered and in-transit resources are accounted for.

## v0.31.10 construction logistics and movement stability
Placement rotation is keyboard-only through N/M; the mouse wheel is reserved for scalable-object size selection or normal camera zoom. The starter material row is positioned relative to the marked stash on every supported playfield size, including migration of legacy misplaced starter piles. Construction frames now separate still-needed resources from material already delivered or reserved/in transit and retain the progress bar until completion. Robot routing uses short obstruction hysteresis plus a smoothed visual chassis pose to avoid edge/replan flicker. Carrier reservations act as bounded leases, and BR-02 builders promptly self-haul any shortage that is not being actively supplied, preventing construction from deadlocking when carriers are unavailable or blocked.

## v0.31.11 independent fleet routing and construction staging

- Delivered construction resources remain visibly staged as boxes at the construction site until consumed by a build step.
- BR-02/CR-01 routes are independently calculated. Other robot routes are soft planning costs rather than blocking reservations.
- Short-horizon reciprocal steering keeps robots physically separated without fleet-wide waiting chains and uses a smoothed avoidance bias to prevent left/right flicker.
- Construction status frames explicitly use the global UI scale transform.

## v0.31.12 construction blueprint rendering
Incomplete habitats, resource structures, corridors, supply channels and walkways are rendered as blueprint-only wireframes with no filled/material surfaces. Unbuilt geometry remains visible in a subdued blue while erected portions use brighter, substantially thicker blue lines. Normal filled materials are applied only after construction reaches 100%.

## v0.31.13 robot-runtime stabilization
Robot simulation is sub-stepped independently from game-speed rendering and the visible chassis follows the authoritative position through a critically damped render spring. Pickup, delivery and construction use stable per-task service/work stations instead of recomputing moving goals each frame. Path following accepts intermediate waypoints with a safe pass radius and slows nearly to a turn-in-place for sharp heading changes, eliminating waypoint orbiting.

Multi-robot operation is fully local: each unit owns its route, resource reservation and recovery watchdog. Stalled units rotate to another persistent service slot without resetting other robots. Small structures use footprint-aware constructor crew limits so carriers retain access, while larger structures can still use larger cooperative teams. Construction safety checks only geometry introduced by the pending build stage; evacuation has exclusive movement control and uses an exterior safety margin, preventing robots from being enclosed as new mesh appears. Delivered site-buffer resources remain visible as staged boxes until consumed.


## v0.31.17 continuous multi-robot traffic
Robot travel no longer executes fixed Cooperative-A* time slots. Each task builds an any-angle, line-of-sight-reduced route before departure, rounds legal corners, predicts the complete fleet trajectory and prefers a separate traffic lane when conflicts are detected. During execution a continuous speed governor negotiates right-of-way without changing the planned steering line; persistent yielding triggers a whole-route replan instead of reverse/steer/spin recovery. Dynamic priority age prevents one robot from being starved indefinitely. Authoritative and rendered robot poses are now identical, and robot simulation uses 90 Hz bounded substeps so NORMAL/QUICK/FAST modes do not expose stop/go solver quantization.

Habitats, resource structures, corridors, supply channels and walkways remain mesh-only at every build state. Blue denotes unbuilt target geometry, yellow denotes installed construction and completed geometry is rendered as a heavier green mesh; filled structure surfaces/textures are intentionally disabled.

## v0.31.18 balanced construction-fleet scheduling
Structure placement no longer triggers full-playfield route searches. Robot paths use a bounded corridor-local A* search that widens only for real detours and caches occupancy checks, keeping planning cost proportional to the useful route instead of map area. Constructor and carrier route planning use separate per-slice budgets so builders cannot monopolize the planner while logistics waits.

The starter depot is a deterministic traffic layout with hull-safe parking, one front pickup lane per material and a clear entry/exit spine. Same-material pickup is serialized only at the source lane; different materials and construction routes continue in parallel. Idle carriers return to dedicated standby bays instead of blocking pallet exits. Construction logistics are carrier-first; builders remain at their worksite unless the site coordinator sees a genuine carrier-service timeout. Pickup/delivery/work stations stay fixed for the current operation so destinations cannot drift while a robot is travelling.

The release QA places an Air Lock, adds a Factory while 6 BR-02 builders and 6 CR-01 carriers are already active, and checks fleet collisions, carrier delivery liveness, low-speed spin, simultaneous movement and placement/update timing. Placement scaling is also checked across legacy small fields and the expanded new-game range up to 1024 m.


## v0.31.19 concurrent logistics lanes and close-range construction
BR-02 construction stations are calculated from the actual rotated structure perimeter. Constructors face the work and stop with the front of the chassis roughly 0.20 m outside the modeled shell instead of using the old footprint-diagonal stand-off ring.

CR-01 starter-depot traffic uses a per-material admission queue with an outer staging spine, one-way lane entry, front pickup bay, and dedicated outbound clearance point. Multiple trips for the same material may be reserved concurrently, while only the front rover enters the pallet throat; queued rovers remain far enough away for the loaded rover's full hull to leave without intersection. Storage Dome pickup stations are also hull-reserved before travel.

Short-horizon fleet prediction now integrates each rover's real current velocity with the same acceleration limit used by movement. A yielding rover is predicted at its actual held velocity rather than being assumed to jump to cruise speed, reducing false future conflicts and stop/go traffic. Construction-stage commit leadership is claimed by a builder actually working at the site, so a delayed original site owner cannot freeze helpers that have already completed the stage work.

## v0.31.20 construction handoff and four-side builder work

Construction logistics now use one explicit material drop area per construction target. Carriers unload there, clear the apron before releasing it, and builders pick the current stage material from that pile before assembly. If the delivered and already-reserved material does not cover the active stage, one builder may self-haul only the uncovered amount from the stash/storage and rejoins the same drop queue. Each construction step is worked from four perimeter sectors with outside-corner transitions, and the next construction segment is reserved as future geometry before robots plan through it.

## v0.40.0 modular baseline

The source tree is now built through explicit implementation/context clusters rather than one monolithic game target. Start future maintenance from `IMPLEMENTATION_CLUSTERS.md`; it maps common requests to the minimum CMake target and source set to inspect. `BASELINE_CONTEXT.md` is the compact handoff for starting a new chat from this release.

Robot geometry path search is isolated in `game_cluster_pathfinding`. Normal movement uses bounded corridor searches; if a rover cannot resolve or make useful route progress for 2.0 seconds, its local route state is discarded and the next attempt becomes a full-width world-geometry route search. Temporary rover positions are not hard A* obstacles during that recovery search, while the continuous traffic layer and hull checks still prevent physical robot intersections.


## v0.40.33 debug blueprint start

The New Game screen includes a `DEBUG START TEMPLATE` toggle. Enabling it locks the playfield to 128x128, imports the bundled construction layout from the supplied 0.43.28 debug save as fresh blueprints, keeps the selected new-game robot counts and starter resource stash, and opens the playfield paused.

## v0.40.32 local fleet awareness and active-only traffic motion

Every rover now refreshes a local nearby-robot map each safety tick. Active 0.5-second motion proposals are pre-checked against nearby robots' certified motion/braking envelopes before contract arbitration, and coarse route replans include current robot positions as temporary obstacles so an active rover can choose a route around parked traffic. The shared time-indexed contract board remains the final collision authority. Idle and working robots never receive collision-avoidance pull-out commands; only robots that currently have an active navigation request may retreat to resolve an active-active deadlock.

## v0.40.31 contract-gameplay integration fixes

The first contract-certified release exposed overly tight starter parking and inconsistent numerical envelope inflation. Safety radii are now identical across initialization, contract arbitration, terminal holds and the final shared-epoch sweep, so a state accepted as initially safe cannot immediately fail only because a later phase counted the same margin again. Partial safety ticks build contracts for their real lease duration, and certified braking can continue across adjacent branch pieces instead of faulting at a 10 ms boundary.

Robot gameplay now plans for the new authority instead of assuming free steering. Local proposals can pivot in place before translating, target speed is capped by remaining braking distance, deadlock retreat favors a lateral pull-out and retreat commands receive arbitration priority without pre-empting occupied passage reservations. New games use wider starter bays; an untouched v0.40.30 starter fleet is migrated to those bays on load. High-level pickup, delivery and build actions still wait for the rover to physically stop before work time advances.

## v0.40.30 contract-certified robot motion

The former robot traffic resolver, rolling collision-avoidance sampler, direct-drive escape logic and post-move overlap repair are no longer movement authorities. High-level construction/logistics code only submits goals. `game_cluster_robots` collects those requests and one shared safety coordinator commits all robot motion at a common simulation epoch.

Each rover keeps a conservative time-indexed motion contract containing its short command lease, every authorized braking branch, terminal stopping holds and reserved passage cells. Local 0.50 s proposals are regenerated every 0.05 s, but a proposal is only advisory until continuous swept-disc checks certify it against static geometry and the complete active contracts of the other robots. Rejected movement follows the previously certified braking branch; it never invents an unchecked emergency steering command. Idle and stopped robots remain reserved obstacles.

Blocked robots first wait. Persistent wait-for cycles are resolved by certified retreat goals to real free pull-out points; an idle blocker can receive the same yield request. If no safe retreat or detour exists, the robot remains blocked rather than being teleported or nudged through another object. Construction-stage mesh growth and autonomous resource-pallet spawning are gated against active motion/braking/terminal reservations so new geometry cannot materialize inside a certified stopping region.

## v0.40.34 compact rover safety corridor and traversable untouched blueprints

BR-02 and CR-01 now share the same 4.84 m/s default travel pace, including constructor travel between construction work positions. Robot navigation no longer adds the former broad comfort halo: the safety corridor targets roughly 1.5x rover chassis width while retaining the full circumscribed physical hull and numerical collision margin as the hard lower bound.

Blueprints with zero construction progress are non-solid for rover navigation. Constructors may claim a supplied blueprint while traffic crosses it; only when a constructor is actually ready to start the first physical build action does the pre-build safety gate evacuate the footprint. Once visible construction progress begins, the erected geometry becomes a normal rover obstacle and future construction stages remain guarded by the scene-admission safety checks.

## v0.40.35 builder construction motion and adaptive structure clearance

BR-02 no longer cancels its own navigation request while travelling to a construction work bay. Constructors assigned to an untouched blueprint may cross that blueprint on the way to the exterior work bay, while other robots are cleared before geometry appears. The pass-through state ends as soon as visible construction starts: traffic reserves the planned footprint immediately, while hard collision geometry advances only on safety-approved committed construction stages. Rover route planning now prefers about 1.0 m of extra clearance around completed habitat/resource structures and progressively relaxes that preference only when the enlarged halo would close the available passage; physical hull collision remains mandatory at every fallback level. The comfort halo is deliberately not part of hard contract certification, so a rover already standing in a legitimate service bay is never faulted merely because a nearby structure completes.

## v0.40.36 robot personal safety zones

Every rover now owns an additional 0.30 m robot-to-robot personal safety zone outside its hard physical safety envelope. Local 0.50 s previews, coarse fleet-aware route search and shared motion-contract arbitration all respect the combined zones of both robots, so traffic yields before reaching the near-contact state instead of repeatedly accepting and braking tiny movements.

Existing saves that already contain physically clear robots inside the new personal-zone spacing are handled as an escape case rather than being faulted or frozen. An active rover may only maintain or increase separation until it leaves the zone; idle and working robots remain stationary. This specifically prevents the accept/brake flicker reproduced by `0-40-35(1).gmsave`, whose two rovers are only about 2.07 m center-to-center.

## v0.40.37 stationary-rover detour routing

An active rover that remains blocked by a stationary fleet member no longer invalidates and retries the same approach indefinitely. After the normal short wait, the safety coordinator identifies a stationary blocker, searches deterministic left/right bypass waypoints outside both rovers' personal safety zones, verifies that the waypoint is reachable through the existing fleet-aware coarse planner, and temporarily routes the active rover around the blocker. The parked/working rover remains fixed. Once the bypass waypoint is reached, the temporary detour is cleared and the original construction/logistics goal resumes automatically. The same recovery applies to every rover role and also detects stationary blockers that caused a coarse `NO ROUTE` result before a robot contract could name them directly.

## v0.40.38 independent rover tasks and builder-first arbitration

The fleet safety coordinator now keeps BR-02 construction and CR-01 logistics independent during traffic arbitration. Occupied certified passages remain non-preemptible, but when fresh builder/carrier movement requests compete for the same free space, the constructor is considered first. In an active-active deadlock, the lower-priority carrier yields before the builder; logistics reservations and construction ownership are retained while either rover waits, detours or replans.

Short certified motion/braking segments now receive an interior static-clearance sample instead of an endpoint-only test. This fixes the `0-40-37.gmsave` failure where a roughly five-centimetre carrier braking segment was accepted because its far endpoint was clear even though the partial substep crossed conservative obstacle clearance. The final guard can also contain a recoverable integration rejection to the offending rover at its last valid position instead of marking unrelated fleet members as `SAFETY FAULT`; that rover then replans while the other robots continue their own tasks.

## v0.40.39 robot safety stability and performance

BR-02 and CR-01 now use a 6.00 m/s default transit speed. The safety coordinator keeps stationary IDLE/WORK holds persistent instead of rebuilding and following braking tubes every 10 ms, and failed full coarse-route searches are rate-limited rather than repeating up to four 18k-cell A* attempts every 50 ms while the blocking geometry is unchanged. Certified straight-line braking trajectories use larger time pieces with analytic chord-error inflation, substantially reducing pairwise tube work without reducing the conservative occupied envelope.

Constructor work holds no longer fault merely because the conservative envelope of the BR-02's own partially revealed target grows around a prevalidated exterior service position. Initial-geometry validation is only an initialization check; stopped stale-contract states are locally re-established as stationary holds when their current physical position is still clear, while real moving contract violations remain faults.

## v0.40.40 lunar construction economy and aluminum

Construction recipes are rebalanced for the lunar-base economy. Every newly generated habitat, resource structure, corridor, supply channel and walkway recipe now uses exactly 50% of the previous total construction mass (nearest kilogram). The reduced structural budget is split between iron and the new Aluminum (`Al`) resource: lightweight pressure shells, habitat frames, solar arrays and antenna structures are aluminum-heavy, while drilling machinery, industrial plants and landing pads remain more iron-heavy. Copper remains the power/data conductor, silicon the electronics/control feedstock and plastic the pressure-seal/insulation/interior polymer feedstock.

Aluminum is fully integrated into starter inventory, pallets, storage, hauling, recovery, construction UI, savegames and the resource-production economy. A powered ore-processing chain produces aluminum alongside iron, copper and silicon. Save schema 11 persists the eighth resource while remaining backward-compatible with older seven-resource saves; older colonies receive one recalculated starter aluminum pallet so future v0.40.40 construction remains possible. Existing in-progress legacy construction plans are not rewritten mid-build.

BR-02 payload capacity is doubled from 1200 kg to 2400 kg and CR-01 from 1800 kg to 3600 kg. Loaded fleets are normalized to those role capacities.
## v0.40.41 gameplay-aware robot traffic and eight-resource depot routing

Robot routing now distinguishes stable traffic obstacles from genuinely moving fleet traffic. Idle, working, blocked and waiting rovers remain static coarse-route obstacles; a higher-priority BR-02 that is only creeping around its construction work bay is also treated as a stable obstacle by a lower-priority CR-01. Actively moving rovers are no longer baked into coarse A* as permanent walls and remain governed by the 0.50 s prediction and shared safety-contract arbitration instead. A stopped active rover with no accepted motion collapses to one persistent stationary hold rather than regenerating zero-distance braking contracts every safety tick.

Stationary-rover detours are now latched until completion or invalidation. Fleet-aware A* bypass waypoints are followed directly instead of being line-of-sight-shortcut through the stationary rover's personal safety zone, eliminating the low-speed forward/brake flicker reproduced by `0-40-40.gmsave`. Lower-priority carriers can therefore pass a working or near-stationary builder without moving the builder or losing their logistics job.

v0.40.40 expanded the starter depot from seven to eight resources without enlarging its boundary inset. The outer Iron/Aluminum pallet lanes could therefore be physically pickup-valid but full-hull route-invalid on a 64x64 field. New games place the eight-pallet row one metre farther from the south boundary, and schema-11 saves that still match the exact v0.40.40 starter-row signature are migrated one metre north. Persisted carrier pickup stations are invalidated so they are recalculated against the migrated row; player-moved and production-created resource piles are not relocated.

## v0.40.42 full-catalog starter manifest and lightweight rover routing

New games now ship a starter manifest sized from one largest available instance of every habitat/resource structure kind rather than mixing STANDARD habitats with SMALL outdoor structures. Scalable habitat families are budgeted at BIG, non-storage outdoor structures at STANDARD and Storage Dome at HUGE. The manifest also includes one additional full-size Solar Panel and Ore Driller, 240 m of corridor stock, 280 m of supply-channel stock, 160 m of walkway stock and a 30% construction-material contingency. The resulting starter reserve is approximately 168 t of construction materials plus 22 t water, 6 t food and 1.2 t medical supplies, so the complete current build catalog can be exercised from a fresh colony before local extraction is mandatory.

Robot route generation is now staged for predictable frame time. A direct certified line is tried first, followed by bounded one/two-bend doglegs around simple obstacles; only genuinely obstructed routes fall back to a coarse A* search. Clearance probing performs cheap geometry-only passes at 1.00/0.65/0.30/0.00 m structure margins and at most two bounded grid searches (0.30 m and physical-hull-only), using a 1.05 m route grid and 4,200-node expansion cap instead of repeated 18,000-node searches. Normal 0.50 s local motion uses a compact steering set and 0.10 s preview samples; the wide steering/reverse recovery fan is generated only after a rover is actually blocked. The 10 ms shared motion-contract authority and hard collision envelopes remain unchanged.

## v0.40.43 hardware GPU enforcement and bounded multi-core planning

The Linux renderer now requires a direct hardware-backed GLX/OpenGL context. Startup queries `GL_VENDOR`, `GL_RENDERER`, `GL_VERSION` and `glXIsDirect()` after the context is made current. Known Mesa software rasterizers such as llvmpipe/softpipe/swrast are rejected instead of silently running the complete 3D renderer on the CPU. The debug frame reports the active GPU renderer so hardware acceleration is visible in-game.

CPU-heavy runtime work uses a persistent engine task pool sized to all logical CPUs visible through the process affinity mask. The game thread participates as one lane and the pool creates one persistent helper for every remaining lane. Per-rover world-revision route validation, D* repair/full route work and short-horizon proposal preparation are dynamically allocated across the pool; heavy route jobs are queued first so multiple blocked rovers can occupy multiple cores immediately. Shared reservation arbitration, safety-contract acceptance, pose commits, logistics ownership and world/construction mutations remain serialized and deterministic. `GAME_CPU_LANES` may explicitly cap runtime lanes for diagnostics. The default clean build also uses all visible logical CPUs and can be capped with `GAME_BUILD_JOBS`.

## v0.40.45 save-profiled construction/logistics performance
The `0-40-43.gmsave` regression exposed two independent frame-time costs. Robot navigation was discarding a valid coarse route after small steering deviations and relaunching A* during ordinary travel, while the OpenGL bitmap font submitted one GPU buffer update/draw per lit 5x7 font pixel. v0.40.45 keeps validated coarse routes until the goal/world changes or blocking recovery explicitly requests a new route, uses a wide low-resolution fallback before a fine narrow A* search for long structure/corridor barriers, reuses the dynamic OpenGL VBO, and batches each text label into one triangle submission.

BR-02 construction is now next-stage-fed instead of waiting for the complete remaining project inventory. CR-01 logistics is blueprint-owned and stages the next construction stage for habitats/resource structures, corridors, supply channels and walkways even when construction dependencies are not yet ready. Site choice favors the least-supplied next stage so one corridor cannot monopolize the carrier while other placed blueprints remain empty.

### v0.40.46 FIFO construction logistics
Carrier robots service one global construction queue in blueprint placement order. The fleet stages the complete remaining bill of materials at the oldest unfinished blueprint before moving to the next. This applies consistently to structures, corridors, supply channels, and walkways; build dependencies still gate BR-02 construction, not CR-01 delivery. Save schema 13 persists the cross-kind placement sequence for new saves.

### v0.40.47 - Builder idle parking / site release

- BR-02 constructors with no executable construction stage release their target, work station, route and action state instead of remaining beside the blueprint.
- Waiting/no-task builders return to their dedicated parking bay beside the starter resource stash.
- Parking-return navigation has lower traffic priority than CR-01 logistics, so a waiting builder cannot block material delivery.
- Builders immediately leave the parking return and take a construction target as soon as a dependency-ready, staged construction stage becomes available.
- Parking bays avoid unfinished blueprint envelopes when possible; if the original spawn bay was built over, a deterministic nearby stash-side fallback is selected.
### v0.40.48 - Structure detours and bounded multi-robot replanning

Robot coarse routing can now leave the direct start-to-goal strip in both directions. The A* search rectangle receives a bounded longitudinal escape band in addition to its lateral detour width, so a rover blocked by a completed structure can first move away from the obstacle, pass around the structure, and then continue toward its destination. The wide coarse fallback is expanded for large structures while the existing fine physical-clearance search remains the narrow-passage fallback.

World changes no longer discard every active rover route. Each rover first validates the small remaining simplified polyline against the new static geometry; routes that are still clear are retained and simply adopt the new world revision. Only actually intersected routes request a full replan. Full coarse-route searches are limited per rendered safety tick and prioritized, so a fleet cannot launch every expensive A* search in one frame. Repeated impossible searches back off and are staggered per rover. Ground-resource quantity changes only affect the navigation revision when the package obstacle radius changes. The shared 10 ms collision-contract authority, resource shipping order, build processing and robot collision-avoidance rules are unchanged.




### v0.40.51 - Corner-safe routing and longer look-ahead

Robot global-route smoothing now preserves the D* Lite soft-clearance cost class instead of allowing a later line-of-sight shortcut to cut back across a structure's inflated corner halo. Sharp route turns are mandatory waypoints: the follower uses a tighter 0.20 m corner acceptance radius, does not visibility-skip across the turn, and brakes before the corner so the swept chassis can rotate onto the outgoing segment without repeatedly rejecting every forward proposal. Narrow passages remain available because adjacent D* edges are never rejected solely for using a higher-cost clearance band.

Local motion prediction is doubled from 0.50 s to 1.00 s. Planner/proposal refresh is reduced from 20 Hz to 10 Hz (0.05 s -> 0.10 s) to lower repeated path calculation load; the authoritative shared motion-contract safety tick remains 100 Hz / 10 ms and still validates every committed movement against static geometry, braking branches, fleet occupancy and passage reservations.

### v0.40.50 - Host-wide CPU worker allocation

The previous ~50% runtime CPU cap and two-route-search cap are removed. `eng::TaskPool` now uses every logical CPU visible to the game by default (one main/game lane plus persistent background workers). Navigation world-revision validation and per-rover route/proposal preparation are distributed dynamically across the pool. When several rovers require D* repair or fallback route searches at the same time, up to one heavy search per available CPU lane can run concurrently. Each D* invocation remains expansion-bounded and resumable, so one rover cannot monopolize a worker indefinitely. Reservation arbitration, robot pose commits, construction/resource ownership, save-state mutation and renderer calls remain on the main thread to preserve deterministic behavior and avoid data races.

### v0.40.49 - Incremental D* Lite navigation and soft clearance costs

Normal BR-02/CR-01 global routing now uses a persistent game-native D* Lite planner. Each rover retains its g/rhs search state while moving; when a construction/world revision blocks the remaining route, already explored navigation cells are re-sampled and only inconsistent vertices are repaired. The search is world-aligned, so it can retreat or detour in any direction instead of being constrained to the current start-to-goal strip. Expensive propagation is capped per invocation and can return PENDING: the rover keeps a certified stationary hold and resumes the same search state on a later rendered frame rather than immediately launching a full A* fallback. A* remains available as the fleet-aware/recovery fallback.

Static navigation now separates hard occupancy from a soft inflated cost field. Completed structures, corridors and resource obstacles receive graded clearance penalties (about 1 m preferred clearance) rather than an all-or-nothing wall; terrain grade adds a small secondary cost. This lets robots prefer wide, flat routes while still using a narrow physically valid passage when necessary. Other robots are deliberately excluded from the persistent global map and continue to be handled by the existing short-horizon prediction, reservation, wait, stationary-detour and retreat logic. The v0.40.47 logistics/build ordering and the authoritative 10 ms collision-contract safety rules are unchanged.
### v0.43.15 - Hydrogen fuel cell and tracked solar collector

The Oxygen Generator now keeps hydrogen produced by water electrolysis instead of treating it as an unused by-product. Build an outdoor **Hydrogen Generator** and connect it to the Oxygen Generator through completed Supply Channels to convert that stored H2 into electricity. Generated electricity serves the connected utility component and can charge its batteries when generation exceeds the current load; hydrogen is not consumed when there is nowhere useful to send the power.

The day/night clock also drives a nonvisualized 3D star position. The reference star rises in the east, crosses the southern sky and sets in the west. Completed Solar Panels use two-axis tracking so the collector head follows the star for maximum incidence while the support pedestal remains fixed. The star itself is intentionally not rendered yet.


### v0.43.17 - On-demand entrances and robot batteries

Habitat structures no longer ship with predefined crew entrances or stair sets. Place a corridor against the pressure hull and that connection creates the hatch at the selected location. Further corridors can reuse the same sealed trunk. The Air Lock keeps its one-base-side rule, but its inside and outside hatches are now derived from the first actual connection instead of two authored door positions.

BR-02 and CR-01 now consume stored electrical charge while travelling, running onboard systems and performing work. Their charge is persistent and visible in the robot details panel. A completed Robot Workshop connected to live power recharges parked robots; charger demand is included in the same physical utility-network power balance as other consumers. Low-charge unloaded robots return to an operational workshop automatically.

The starter packs are calibrated against a full uninterrupted Stage-1/Stage-2 bootstrap: BR-02 starts with 48 kWh and CR-01 with 76 kWh. The regression reaches Stage 2 without recharging and retains about 15.7% and 13.9% respectively, leaving more than the requested 10% reserve.


### v0.43.18 perimeter circulation and render-layout debug switch

A permanent 2.25 m rover circulation band is reserved inside the playfield boundary. New structures and their non-crossable service/access clearances cannot occupy it, so edge-side construction cannot eliminate the last route around the colony. A subtle line marks the inner edge of the reserved band. Existing saves are not repositioned.

When the debug frame is enabled it now includes a `MESH` / `TEXTURED` layout switch. The project currently has no texture/material asset pipeline, so textured mode deliberately uses the same procedural mesh renderer for now; the mode exists as the stable hook for future textured rendering.

### v0.43.19 seamless corridor attachment angles

Corridor attachment points now follow the cursor continuously around the complete usable structure hull instead of jumping between predefined/cardinal face slots. Existing corridor entrances and functional gate sectors still reserve their physical space; when the selected angle is occupied, placement slides to the nearest free angular position rather than jumping to an unrelated face. Storage Dome crew-corridor placement follows the same exact-angle behavior while cargo gates remain protected.

When two structures are close enough for a direct unobstructed connection, the pressure corridor between their docking vestibules is forced to a straight centerline. The local vestibules may still meet differently angled hull surfaces, but a short corridor itself no longer twists into an S-shape merely to follow both endpoint tangents.

### v0.43.20 shorter corridor blueprint start
When corridor placement is first hovered over a structure, the temporary structure-attached blueprint stub is now much shorter (1.35 m instead of 2.75 m). The fallback start marker is also reduced to 1.10 m. Once the source is selected, corridor length continues to follow the actual destination and routing normally.

### v0.43.21 minimal corridor start and corridor-safe placement envelopes
The pre-click corridor hint on a structure no longer previews a real corridor section. It now shows only a compact 0.56 m docking/orientation hint; the full generated entrance, docking transition and routed corridor appear after the source is selected.

Every new structure now reserves a larger ground-placement rectangle derived from the real corridor hardware: 1.70 m generated entrance depth + 1.75 m docking transition = 3.45 m reserve on every side. Two structures placed at the minimum legal spacing therefore still retain enough clear ground for opposing docking assemblies and a short straight pressure corridor. The reserve is visible in structure placement/step-0 blueprints. Existing saves are not moved or rejected; the rule applies to new placement.

### v0.43.22 Bio Dome front/back corridor connections
Bio Domes now have sealed pressure-envelope end caps on both ends of the greenhouse barrel. Corridor placement can therefore create normal on-demand pressure hatches on the front and back faces as well as along the curved sides. The attachment remains continuous/free-angle and does not add predefined entrances. Existing saves are compatible.

### v0.43.23 doubled playfield sizes

New games now default to a 128 x 128 playfield instead of 64 x 64. The selectable range is doubled consistently from 32 x 32 through 1024 x 1024 in 32 m steps. The debug start template is likewise locked to 128 x 128. Legacy saves down to the historical 16 x 16 size remain loadable, while saves up to 1024 x 1024 are now accepted.

### v0.43.24 scrollable selection/info panel

The upper-left selection/info panel now behaves as a fixed viewport above the build bar. If robot telemetry, structure warnings, resource inventories or other detail rows exceed the available vertical space, the panel shows a scrollbar and the mouse wheel scrolls the contained information. Wheel input over the panel is consumed by the UI, so it does not zoom the world or change a structure-placement size. Selecting a different object resets the panel to the top. Short panels remain unchanged and do not show a scrollbar.

### v0.44.0 Bio Dome hydroponics
Bio Domes now operate real hydroponics bays instead of producing Food from a fixed background rate. Bay count scales with dome size (Small 2, Standard 4, Mid 6, Big 8). Each bay can be independently set to Empty, Potato, Wheat, Soybean, Pea, Lettuce, Tomato or Strawberry from the selected Bio Dome's status frame. The table shows the crop purpose, grow time, Food yield, water and lighting demand, completed harvest count, and a live progress bar for each bay.

Growth is supply-driven: a configured bay requires electrical power, water and breathable air. Full growth speed requires at least 95% breathable air; 80-95% supports reduced growth, and below 80% pauses the crop. Harvests automatically enter the existing Food/resource system and the bay begins its next cycle. Schema-23 saves retain crop/progress/harvest state; older saves are migrated to a balanced starter crop mix.


### v0.44.1 POV interior collision
Completed structures now use their rendered interior geometry for first-person collision. The astronaut can no longer walk through beds, tables, consoles, hydroponics racks, tanks, production machines, cabinets, internal partitions, Storage Dome racks/cargo packages, or Robot Workshop service equipment. The collision test uses the full body radius and vertical span, while the authored floor/deck remains walkable and generated doors/entrance aisles remain passable.

### v0.44.2 Bio Dome commissioning, crop dropdowns and photoperiod
Newly placed/constructed Bio Domes no longer receive an automatic crop mix. Every hydroponics bay starts **EMPTY** and stays idle until the player selects a crop. Existing schema-23 saves preserve their configured crops; schema <=22 migration now creates empty bays instead of assigning starter crops.

The Bio Dome status frame exposes crop controls only after the structure is fully built. Completed domes use a compact two-column bay table. Each bay has one dropdown containing EMPTY / REMOVE CROP plus Potato, Wheat, Soybean, Pea, Lettuce, Tomato and Strawberry; changing or removing a crop resets that bay's current growth cycle while retaining its lifetime harvest counter.

Hydroponics now follow a controlled greenhouse **16 h light / 8 h dark** photoperiod: grow lights are active from 06:00 to 22:00 and the dark/rest phase runs from 22:00 to 06:00. Crop growth and crop water demand occur only during the light phase. The Bio Dome base climate-control load remains active continuously, and growth additionally requires electrical power, water and at least 80% breathable air (95%+ for full speed). Completed Bio Domes visually dim their shell/interior/glazing during the dark phase so the rendered greenhouse matches the simulation state.

### v0.44.3 corridor placement rejection tooltips
Invalid corridor previews now explain why placement is rejected directly beside the mouse cursor. The tooltip distinguishes reserved Air Lock passenger sides, unavailable structure/storage docking faces, attempts to connect a structure to itself, corridor points that are too close together, blocked route geometry, gate/service-clearance conflicts, and post-merge pressure-network conflicts. The existing red invalid preview remains visible underneath the explanation.

### v0.50.0 three-stage game structure
The game is now organized into three separate top-level content stages: **Stage 1 - Planning**, **Stage 2 - Preparing Base with Robots**, and **Stage 3 - Full Manned Moon Base**. The New Game screen selects the stage before the session is created and defaults to Stage 2.

Stage 2 contains the complete existing robot-preparation game: autonomous BR-02/CR-01 construction, resources, utilities, habitats, colony progression, POV mode and all related simulation remain there. Stage 1 is now the independent Earth-side company/planning game, while Stage 3 starts from the completed debug-base scenario for future crew gameplay. The three phases remain isolated and do not silently run each other's simulation systems.

Save schema 24 records the top-level game stage. Existing schema 1-23 savegames have no stage field and therefore load directly into Stage 2, preserving the previous game as the robot-preparation phase.


### v0.50.1 Stage-1 mission planning, contracts and technology
Stage 1 is now an operational company/mission-planning game rather than an empty shell. The space company starts with seed capital, accepts up to three contracts in parallel, receives a deposit immediately, advances contract work in planning days, and receives a separate finish payout when work completes. Early and mid-program commercial contracts are repeatable so research spending cannot permanently deadlock the campaign; the final lunar cargo contract is a one-time program milestone.

The same company cash balance funds a 16-node dependency-based technology tree. The progression starts with mission systems engineering, structures/materials, propulsion and avionics/GNC; develops autonomous robotics, power/storage, an orbital launch vehicle and closed-loop life support; then unlocks lunar transfer/navigation, lunar surface construction, ISRU/water processing and pressurized habitats/airlocks. The final branch adds controlled-environment agriculture and lunar industry/manufacturing before unlocking **Stage-2 Module Competence** and the integrated **Robotic Lunar Base Mission Architecture**. Higher research levels unlock higher-value contracts.

Stage 1 has Contracts, Tech Tree, Plan Mission and Company Site views plus Pause/1x/5x/20x planning-time controls and remains isolated from Stage-2 robot/construction simulation. The current save schema persists Stage-1 funds, elapsed planning time, time speed, planning view, unlocked technologies, contract history and mission configuration. Schema 24 Stage-1 placeholder saves migrate to a fresh Stage-1 planning economy; older schema 1-23 saves continue to load as Stage 2.

### v0.50.2 real technology tree and Stage-3 starting base
The Stage-1 technology view is now laid out as a real dependency tree rather than a matrix. Research depth forms eight ordered levels from foundations to mission readiness, prerequisite links are directional, and multiple incoming branches remain visible for integrated technologies. Wide layouts grow left-to-right; compact/high-zoom layouts rotate the same hierarchy top-to-bottom so the tree remains readable.

Stage 3 is no longer an empty placeholder. A new Stage-3 game automatically imports the same 128 x 128 debug-base scenario used by Stage 2, but every imported habitat, outdoor/resource structure, corridor, supply channel and walkway starts construction-complete. Stage 3 uses the normal 3D playfield/simulation surface, providing a built physical base as the starting condition for future crew-focused gameplay. Stage-2 debug starts are unchanged and still import the layout as blueprints.


### v0.50.3 Stage-1 lunar mission planning

Stage 1 now has a `PLAN MISSION` tab beside Contracts and Tech Tree. The player selects a rocket and lunar cargo lander, edits the lunar cargo manifest by resource type, and sees payload capacity, vehicle cost, cargo cost, total mission price and current company funds.

The mission starts with a minimum viable Stage-2 manifest generated from the same construction recipes used by the robot-preparation game: redundant solar power, battery storage, water extraction/storage/purification, airlock, oxygen generator, canteen, six-person quarters, landing pad, robot workshop, corridor/supply/walkway stock, 15% construction contingency, and initial water/food/medical reserves. The current baseline is 49,102 kg, well below the default 180,000 kg landed-payload capacity.

Funding is disabled until the selected rocket/lander research is available, Stage-2 Module Competence and Robotic Lunar Base Mission Architecture are unlocked, every mandatory cargo minimum is met, the complete manifest fits the selected vehicle pair, and the company can afford the calculated cost. Once funded, the mission configuration is locked and persisted by save schema 26.


### v0.50.4 Stage-1 3D company site

Stage 1 now opens on a freely viewable 3D Earth-side launch campus inspired by the functional zoning of major coastal launch centers. The campus is fictional rather than a copy of a real site and includes a Program & Contracts Office, Research & Engineering facility, Vehicle Assembly Building, Cargo Integration Facility, Mission Control Center, Communications Center, remote Propulsion Test Center and Launch Complex.

The site is a functional planning hub: clicking Program & Contracts opens Contracts; Research & Engineering and Propulsion Test open the Tech Tree; Vehicle Assembly, Cargo Integration, Mission Control, Communications and the Launch Complex open Plan Mission. Mouse wheel zooms, middle mouse orbits, right mouse pans and W/A/S/D translates the camera. The existing bottom tabs remain available as direct shortcuts.

Save schema 27 permits `PlanningView::Site` to persist while retaining the numeric values of the schema-26 Contracts/Tech Tree/Mission views for compatibility. New Stage-1 games start on the company site.

### v0.50.5 facility-driven mission preparation

Stage 1 mission preparation is now an ordered facility workflow rather than one all-in-one purchase screen. The mission must pass **Research -> Design -> Test -> Refine -> Plan -> Confirm/Fund -> Build -> Integrate Cargo -> Final Confirm -> Launch**. Each gate is owned by the physical campus facility that performs the work: Research & Engineering owns research/design/refinement, Propulsion Test owns qualification, Mission Control owns the flight/cargo plan, Program & Contracts owns budget authorization, Vehicle Assembly owns hardware production, Cargo Integration owns payload integration, Communications owns the final readiness review, and the Launch Complex owns launch execution.

The company site highlights the facility required for the next gate. Clicking any campus building opens that facility's mission-preparation station; Program & Contracts still provides a Contracts shortcut and Research & Engineering still provides a Tech Tree shortcut. The rocket/lander selection is frozen during Design, the lunar resource manifest is frozen during Plan, and Program Authorization performs the one-time mission payment. Build and launch cannot be reached by funding alone.

Save schema 28 persists the current mission-preparation gate and selected facility. Schema-26/27 paid missions migrate to the Build gate; unpaid missions migrate to the Research gate.


### 0.50.10 Stage-1 campaign balance and coaching

- Adds a persistent context-sensitive **NEXT STEP** navigation shortcut and direct facility action on the 3D campus; never purchases or submits work without a separate click.
- Commercial projects: faster completion for non-tutorial jobs; use **ADVANCE TO NEXT REPORT** to advance exactly to the nearest active project delivery and pause.
- Technical evidence: first completed customer project provides a 20% discount to its target technology (distinct evidence capped at 35%). Previously completed projects still apply without a save schema change.
- One-time first-customer completion premium (+20% final payment for projects 2–11), plus transparent investor reputation awards when unique completed projects reach 3, 6, and 9 (EUR 750K, 1.5M, and 3M). Repeat projects pay their normal price and remain available to prevent deadlocks.
- Contract list ranks work ready for submission, active jobs and first-time relevant opportunities before repeat work; research shows a funding shortcut when unaffordable.
- Stage-2 and Stage-3 mechanics are unchanged. Save schema 29 is preserved; old contract IDs and progress are retained.
