#include "game/game_app.hpp"
#include "game/util/world_math.hpp"
#include "game/ui/layout.hpp"
#include "game/world/world_labels.hpp"
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <limits>
#include <sstream>
#include <string>
#include <vector>

namespace game {
using namespace eng;
using namespace layout;
using namespace world_labels;

namespace {
struct ConstructionFrame {
    ConstructionTargetRef target{};
    Vec3 anchor{};
    std::string title{};
    ResourceBundle needed{};
    ResourceBundle shipped{};
    float progress{0.0f};
    float materials_progress{0.0f};
    std::uint8_t step{0};
    std::uint8_t total_steps{1};
    float screen_x{0.0f};
    float screen_y{0.0f};
    Rect rect{};
    bool selected{false};
};

bool project_world_to_logical(const Mat4& m,Vec3 p,int viewport_width,int viewport_height,float ui_scale,float& sx,float& sy){
    const float cx=m.m[0]*p.x+m.m[4]*p.y+m.m[8]*p.z+m.m[12];
    const float cy=m.m[1]*p.x+m.m[5]*p.y+m.m[9]*p.z+m.m[13];
    const float cw=m.m[3]*p.x+m.m[7]*p.y+m.m[11]*p.z+m.m[15];
    if(cw<=0.001f) return false;
    const float nx=cx/cw,ny=cy/cw;
    sx=(nx*0.5f+0.5f)*(float)viewport_width/std::max(0.01f,ui_scale);
    sy=(1.0f-(ny*0.5f+0.5f))*(float)viewport_height/std::max(0.01f,ui_scale);
    return nx>=-1.08f && nx<=1.08f && ny>=-1.08f && ny<=1.08f;
}

Vec3 path_midpoint(const std::vector<Vec3>& path,float lift){
    if(path.empty()) return {0,lift,0};
    if(path.size()==1) return path.front()+Vec3{0,lift,0};
    float total=0.0f;
    for(std::size_t i=0;i+1<path.size();++i) total+=length(path[i+1]-path[i]);
    if(total<=0.001f) return path.front()+Vec3{0,lift,0};
    float remaining=total*0.5f;
    for(std::size_t i=0;i+1<path.size();++i){
        const Vec3 delta=path[i+1]-path[i];
        const float segment=length(delta);
        if(segment<=0.001f) continue;
        if(remaining<=segment){
            const float t=std::clamp(remaining/segment,0.0f,1.0f);
            return path[i]+delta*t+Vec3{0,lift,0};
        }
        remaining-=segment;
    }
    return path.back()+Vec3{0,lift,0};
}

ResourceBundle shipped_resources(const ConstructionResourcePlan& plan,std::uint8_t step,
                                 const ResourceBundle* delivered,const ResourceBundle& reserved){
    const ResourceBundle remaining=plan.remaining(step);
    ResourceBundle shipped{};
    for(std::size_t i=0;i<kMaterialResourceCount;++i){
        const auto material=static_cast<MaterialResource>(i);
        const std::int64_t covered=(delivered?delivered->amount(material):0)+reserved.amount(material);
        shipped.amount(material)=std::min(remaining.amount(material),std::max<std::int64_t>(0,covered));
    }
    return shipped;
}

ResourceBundle remaining_need(const ConstructionResourcePlan& plan,std::uint8_t step,
                              const ResourceBundle* delivered,const ResourceBundle& reserved){
    ResourceBundle need=plan.remaining(step);
    const ResourceBundle shipped=shipped_resources(plan,step,delivered,reserved);
    for(std::size_t i=0;i<kMaterialResourceCount;++i){
        const auto material=static_cast<MaterialResource>(i);
        need.amount(material)=std::max<std::int64_t>(0,need.amount(material)-shipped.amount(material));
    }
    return need;
}

std::string short_mass(std::int64_t kg){
    std::ostringstream out;
    if(kg>=10000){ out<<std::fixed<<std::setprecision(0)<<(double)kg/1000.0<<"t"; }
    else if(kg>=1000){ out<<std::fixed<<std::setprecision(1)<<(double)kg/1000.0<<"t"; }
    else out<<kg<<"kg";
    return out.str();
}

std::vector<std::string> resource_lines(const char* label,const ResourceBundle& bundle,const char* empty_text){
    std::vector<std::string> tokens;
    for(std::size_t i=0;i<kMaterialResourceCount;++i){
        const auto material=static_cast<MaterialResource>(i);
        const std::int64_t amount=bundle.amount(material);
        if(amount<=0) continue;
        tokens.push_back(std::string(material_resource_symbol(material))+" "+short_mass(amount));
    }
    if(tokens.empty()) return {std::string(label)+"  "+empty_text};
    std::vector<std::string> lines;
    for(std::size_t i=0;i<tokens.size();i+=2){
        std::string line=i==0?std::string(label)+"  ":std::string(std::char_traits<char>::length(label)+2,' ');
        line+=tokens[i];
        if(i+1<tokens.size()) line+="   "+tokens[i+1];
        lines.push_back(std::move(line));
    }
    return lines;
}

bool overlaps(const Rect& a,const Rect& b,float pad=4.0f){
    return a.x < b.x+b.w+pad && a.x+a.w+pad > b.x &&
           a.y < b.y+b.h+pad && a.y+a.h+pad > b.y;
}
}

void GameApp::render_astronaut_status(Renderer& r,const Mat4& view_projection) const {
    if(selected_astronaut_<0)return;
    const auto& actor=test_astronauts_[selected_astronaut_];
    const auto pose=astronaut_rest_pose(actor);
    const Vec3 anchor=astronaut_resting(actor)?
        pose.feet+world_math::rotate_y({0,.53f,.75f},pose.heading_degrees):actor.position+Vec3{0,kAstronautMeshHeight+.08f,0};
    float x=0,y=0;
    if(!project_world_to_logical(view_projection,anchor,r.width(),r.height(),ui_scale_,x,y))return;

    const float logical_w=ui_width(r),logical_h=ui_height(r);
    constexpr float width=290.f,height=124.f,gap=10.f;
    if(y<STATUS_BAR_H+height+gap || y>=logical_h-BUILD_BAR_H || x<0.f || x>logical_w)return;
    Rect panel{std::clamp(x-width*.5f,8.f,logical_w-width-8.f),y-height-gap,width,height};
    if(!keep_clear_of_activity_log(panel))return;
    r.draw_line({x,y},{std::clamp(x,panel.x,panel.x+panel.w),panel.y+panel.h},theme_.accent,1.f);
    hud_panel(r,panel,theme_);

    const auto& role=kAstronautRoles[selected_astronaut_];
    const char* activity="IDLE";
    switch(actor.activity){
        case AstronautActivity::Shelter:activity=actor.destination?"HEADING INDOORS":"SHELTERING";break;
        case AstronautActivity::Duty:{
            constexpr std::array<const char*,4> jobs{"CHECKING STOCK","MONITORING SYSTEMS","CROP DUTY","SICK BAY DUTY"};
            activity=actor.destination?"HEADING TO DUTY":jobs[selected_astronaut_];break;
        }
        case AstronautActivity::ToBed:activity="HEADING TO BED";break;
        case AstronautActivity::Sleeping:activity="SLEEPING IN QUARTERS";break;
        case AstronautActivity::Knockout:activity="KNOCKOUT / EXHAUSTED";break;
        case AstronautActivity::Resupply:activity="RETURNING FOR SUIT AIR";break;
        case AstronautActivity::Construction:activity=actor.destination?"HEADING TO BUILD SITE":"ASSEMBLING BLUEPRINT";break;
        default:break;
    }
    if(actor.health<=0.f)activity="DECEASED";
    if(actor.destination){
        if(actor.waiting_for_door)activity="WAITING AT DOOR";
        else if(actor.activity==AstronautActivity::Manual)
            activity=actor.speed>.025f?"WALKING":"WAITING FOR CLEARANCE";
    }
    game_label_fitted(r,{panel.x+11,panel.y+8,width-22,16},role.name,.52f,theme_);
    game_label_fitted(r,{panel.x+11,panel.y+28,width-22,14},
                      std::string(role.job)+(actor.suited?" / EVA SUIT":" / HABITAT COVERALL"),.42f,theme_,true);
    game_label_fitted(r,{panel.x+11,panel.y+47,width-22,14},
                      "HEALTH "+std::to_string((int)std::lround(actor.health*100.f))+"%",.42f,theme_);
    r.draw_rect({panel.x+105,panel.y+50,width-116,8},theme_.panel2);
    r.draw_rect({panel.x+105,panel.y+50,(width-116)*actor.health,8},{.28f,.80f,.50f,1.f});
    const auto percent=[](double value){return std::to_string((int)std::lround(value*100.0))+"%";};
    game_label_fitted(r,{panel.x+11,panel.y+65,width-22,14},
                      "HUNGER "+percent(actor.hunger)+"    THIRST "+percent(actor.thirst),.42f,theme_);
    game_label_fitted(r,{panel.x+11,panel.y+84,width-22,14},
                      "FATIGUE "+percent(actor.fatigue/kCrewExhausted)+"    SUIT AIR "+
                      percent(actor.suit_oxygen_kg/kSuitOxygenCapacityKg),.42f,theme_);
    game_label_fitted(r,{panel.x+11,panel.y+103,width-22,15},std::string("ACTIVITY  ")+activity,.42f,theme_);
}

void GameApp::render_construction_status_frames(Renderer& r){
    // Construction frames explicitly use the same global 2D transform as the
    // rest of the HUD. World projection is converted back to logical UI units,
    // so panel geometry, progress bars, text and spacing all follow UI SCALE.
    r.set_2d(ui_scale_);
    construction_priority_button_rect_={};construction_priority_button_target_={};
    std::vector<ConstructionFrame> frames;
    frames.reserve(placed_habitats_.size()+placed_resources_.size()+
                   corridor_network_.connections().size()+utility_network_.connections().size()+
                   walkway_network_.connections().size());

    const auto selected=selected_construction_target();

    auto add_frame=[&](ConstructionTargetRef target,Vec3 anchor,std::string title,float progress,
                       const ConstructionResourcePlan& plan,std::uint8_t step){
        if(progress>=1.0f) return;
        ConstructionFrame f;
        f.target=target;
        f.anchor=anchor;
        f.title=std::move(title);
        f.progress=std::clamp(progress,0.0f,1.0f);
        f.step=step;
        f.total_steps=construction_target_total_steps(target);
        f.selected=target.same_as(selected);
        const ResourceBundle* delivered=construction_site_buffer(target);
        const auto total=plan.total().total_amount();
        const auto undelivered=remaining_need(plan,step,delivered,{}).total_amount();
        f.materials_progress=total>0?std::clamp(1.f-(float)undelivered/(float)total,0.f,1.f):1.f;
        if(f.selected){
            const auto reserved=construction_site_reserved(target);
            f.shipped=shipped_resources(plan,step,delivered,reserved);
            f.needed=remaining_need(plan,step,delivered,reserved);
        }
        frames.push_back(std::move(f));
    };

    for(std::size_t i=0;i<placed_habitats_.size();++i){
        const auto& h=placed_habitats_[i];
        if(h.construction.complete()) continue;
        const auto& mesh=habitat_models_.mesh(h);
        add_frame({ConstructionTargetKind::Habitat,i},h.position+Vec3{0,mesh.height+0.85f,0},
                  habitat_instance_name(h),h.construction.progress(),h.resource_plan,h.construction.step);
    }
    for(std::size_t i=0;i<placed_resources_.size();++i){
        const auto& item=placed_resources_[i];
        if(item.construction.complete()) continue;
        const auto& mesh=resource_models_.mesh(item);
        add_frame({ConstructionTargetKind::Resource,i},item.position+Vec3{0,mesh.height+0.85f,0},
                  resource_instance_name(item),item.construction.progress(),item.resource_plan,item.construction.step);
    }
    const auto& corridors=corridor_network_.connections();
    for(std::size_t i=0;i<corridors.size();++i){
        const auto& c=corridors[i];
        if(c.construction.complete()) continue;
        add_frame({ConstructionTargetKind::Corridor,i},path_midpoint(c.path,3.15f),"CORRIDOR #"+std::to_string(i+1),
                  c.construction.progress(),c.resource_plan,c.construction.step);
    }
    const auto& utilities=utility_network_.connections();
    for(std::size_t i=0;i<utilities.size();++i){
        const auto& c=utilities[i];
        if(c.construction.complete()) continue;
        add_frame({ConstructionTargetKind::Utility,i},path_midpoint(c.path,1.65f),std::string(utility_kind_name(c.kind))+" #"+std::to_string(i+1),
                  c.construction.progress(),c.resource_plan,c.construction.step);
    }
    const auto& walkways=walkway_network_.connections();
    for(std::size_t i=0;i<walkways.size();++i){
        const auto& w=walkways[i];
        if(w.construction.complete()) continue;
        add_frame({ConstructionTargetKind::Walkway,i},path_midpoint(w.path,1.80f),"WALKWAY #"+std::to_string(i+1),
                  w.construction.progress(),w.resource_plan,w.construction.step);
    }

    if(frames.empty()) return;
    const float aspect=(float)r.width()/std::max(1,r.height());
    const Mat4 vp=first_person_mode_==FirstPersonMode::Active?first_person_.view_projection(aspect):camera_.view_projection(aspect);
    std::vector<ConstructionFrame> visible;
    visible.reserve(frames.size());
    for(auto& frame:frames){
        if(project_world_to_logical(vp,frame.anchor,r.width(),r.height(),ui_scale_,frame.screen_x,frame.screen_y)) visible.push_back(std::move(frame));
    }
    std::sort(visible.begin(),visible.end(),[](const ConstructionFrame& a,const ConstructionFrame& b){
        if(a.selected!=b.selected)return a.selected;
        return a.screen_y<b.screen_y;
    });

    const float logical_w=ui_width(r),logical_h=ui_height(r);
    const float bottom_guard=first_person_mode_==FirstPersonMode::Active?8.0f:BUILD_BAR_H+8.0f;
    std::vector<Rect> occupied;
    occupied.reserve(visible.size()+3);
    if(first_person_mode_!=FirstPersonMode::Active){
        if(selection_kind_!=SelectionKind::None)occupied.push_back(selection_kind_==SelectionKind::GroundResource && selected_ground_resources_.size()<=1?ground_resource_panel_rect():selection_panel_rect());
        else occupied.push_back({PLAYFIELD_MARGIN,STATUS_BAR_H+PLAYFIELD_MARGIN,560,130});
        if(debug_frame_visible())occupied.push_back(debug_frame_rect());
        const auto log=activity_log_panel_rect();
        if(activity_log_visible() && log.h>0.f)occupied.push_back(log);
    }
    // Normal gameplay reserves the right-edge progression checklist so floating
    // construction frames never cover objectives or the crew-readiness milestone.
    if(progress_tree_visible())occupied.push_back(progress_tree_panel_rect());
    if(first_person_mode_==FirstPersonMode::Off) occupied.push_back(build_queue_panel_rect());
    for(auto& frame:visible){
        const auto needed_lines=frame.selected?resource_lines("NEEDED",frame.needed,"NONE"):std::vector<std::string>{};
        const auto shipped_lines=frame.selected?resource_lines("SHIPPED",frame.shipped,"NONE"):std::vector<std::string>{};
        const float width=frame.selected?255.0f:126.0f;
        const float height=frame.selected?108.0f+18.0f*(float)(needed_lines.size()+shipped_lines.size()):17.0f;
        float x=frame.screen_x-width*0.5f;
        float y=frame.screen_y-height-13.0f;
        x=std::clamp(x,6.0f,std::max(6.0f,logical_w-width-6.0f));
        y=std::clamp(y,STATUS_BAR_H+6.0f,std::max(STATUS_BAR_H+6.0f,logical_h-bottom_guard-height));
        Rect candidate{x,y,width,height};
        const auto obstructed=[&](const Rect& bounds){
            return std::any_of(occupied.begin(),occupied.end(),[&](const Rect& other){return overlaps(bounds,other);});
        };
        if(frame.selected && obstructed(candidate)){
            std::vector<float> columns{x,6.f,logical_w-width-6.f};
            std::vector<float> rows{y,STATUS_BAR_H+6.f,logical_h-bottom_guard-height};
            for(const auto& other:occupied){
                columns.push_back(other.x-width-6.f);
                columns.push_back(other.x+other.w+6.f);
                rows.push_back(other.y-height-6.f);
                rows.push_back(other.y+other.h+6.f);
            }
            float best=std::numeric_limits<float>::max();
            for(float left:columns)for(float top:rows){
                if(left<6.f || left+width>logical_w-6.f || top<STATUS_BAR_H+6.f ||
                   top+height>logical_h-bottom_guard)continue;
                const float cost=(left-x)*(left-x)+(top-y)*(top-y);
                if(cost>=best)continue;
                const Rect shifted{left,top,width,height};
                if(obstructed(shifted))continue;
                candidate=shifted;
                best=cost;
            }
        }else{
            // Offset small markers vertically before they can cover another panel.
            for(int attempt=0;attempt<12 && obstructed(candidate);++attempt){
                const float direction=(attempt%2==0)?1.f:-1.f;
                const float distance=(float)(attempt/2+1)*(height+5.f);
                candidate.y=std::clamp(y+direction*distance,STATUS_BAR_H+6.f,
                                       std::max(STATUS_BAR_H+6.f,logical_h-bottom_guard-height));
            }
        }
        if(!keep_clear_of_activity_log(candidate))continue;
        frame.rect=candidate;
        occupied.push_back(candidate);

        const Color track{0.09f,0.13f,0.15f,0.96f};
        const Color build_bar{1.00f,0.68f,0.12f,0.98f};
        const Color material_bar{0.21f,0.78f,0.93f,0.98f};
        const auto draw_bar=[&](Rect bounds,float fraction,Color fill){
            r.draw_rect(bounds,track);
            if(fraction>0.f)r.draw_rect({bounds.x,bounds.y,bounds.w*fraction,bounds.h},fill);
        };
        if(!frame.selected){
            draw_bar({candidate.x,candidate.y,candidate.w,7},frame.materials_progress,material_bar);
            draw_bar({candidate.x,candidate.y+10,candidate.w,7},frame.progress,build_bar);
            continue;
        }

        const Color border{0.31f,0.79f,0.93f,0.95f};
        const Color fill=kHudFill;
        r.draw_rect(candidate,fill);
        r.draw_line({candidate.x,candidate.y},{candidate.x+candidate.w,candidate.y},border,1.5f);

        std::ostringstream title;
        title<<frame.title<<"   STEP "<<(int)frame.step<<"/"<<(int)frame.total_steps
             <<"   "<<(int)std::lround(frame.progress*100.0f)<<"%";
        const auto rank=construction_priority_rank(frame.target);
        if(rank!=kNoRobotIndex)title<<"   PRIO "<<rank+1;
        else if(construction_automatic_priority(frame.target))title<<"   AUTO LINK";
        game_label_fitted(r,{candidate.x+8.0f,candidate.y+6.0f,candidate.w-16.0f,13.0f},title.str(),0.43f,theme_);

        const float bar_x=candidate.x+8.f;
        const float bar_width=candidate.w-16.f;
        game_label_fitted(r,{bar_x,candidate.y+23,bar_width,12},"MATERIALS AT SITE  "+
            std::to_string((int)std::lround(frame.materials_progress*100.f))+"%",.40f,theme_);
        draw_bar({bar_x,candidate.y+36,bar_width,7},frame.materials_progress,material_bar);
        game_label_fitted(r,{bar_x,candidate.y+46,bar_width,12},"CONSTRUCTION  "+
            std::to_string((int)std::lround(frame.progress*100.f))+"%",.40f,theme_);
        draw_bar({bar_x,candidate.y+59,bar_width,7},frame.progress,build_bar);

        float text_y=candidate.y+71.0f;
        for(const std::string& line:needed_lines){
            game_label_fitted(r,{candidate.x+8.0f,text_y,candidate.w-16.0f,14.0f},line,0.36f,theme_,true);
            text_y+=18.0f;
        }
        for(const std::string& line:shipped_lines){
            game_label_fitted(r,{candidate.x+8.0f,text_y,candidate.w-16.0f,14.0f},line,0.36f,theme_,true);
            text_y+=18.0f;
        }
        construction_priority_button_rect_={candidate.x+8,candidate.y+candidate.h-30,candidate.w-16,22};
        construction_priority_button_target_=frame.target;
        const bool queued=construction_priority_rank(frame.target)!=kNoRobotIndex;
        if(ui::button(r,ui_input_,construction_priority_button_rect_,queued?"REMOVE PRIORITY":"PRIORITIZE BUILD",theme_)){
            toggle_construction_priority(frame.target);selection_marquee_active_=false;selection_marquee_dragged_=false;
        }

    }
}

void GameApp::render_supply_indicators(Renderer& r){
    const float aspect=(float)r.width()/std::max(1,r.height());
    const Mat4 vp=first_person_mode_==FirstPersonMode::Active?first_person_.view_projection(aspect):camera_.view_projection(aspect);
    const float pulse=0.48f+0.52f*(0.5f+0.5f*std::sin(ui_time_seconds_*2.0943951f));
    const auto draw=[&](Vec3 position,float height,const SupplyState& supply,bool inside,bool storage_full,bool power_enabled){
        float x=0,y=0;if(!project_world_to_logical(vp,position+Vec3{0,height+1.0f,0},r.width(),r.height(),ui_scale_,x,y))return;
        if(!power_enabled){
            const Color info{0.34f,0.84f,1.0f,1.0f};
            r.draw_rect({x-8,y-16,16,18},{0.02f,0.06f,0.09f,0.95f});
            r.draw_line({x,y-13},{x,y-11},info,2.5f);
            r.draw_line({x,y-8},{x,y-2},info,2.5f);
        }else if(supply.warnings){
            const Color color{1.0f,0.68f,0.10f,pulse};
            r.draw_line({x,y-16},{x-10,y+3},color,2.5f);r.draw_line({x-10,y+3},{x+10,y+3},color,2.5f);r.draw_line({x+10,y+3},{x,y-16},color,2.5f);
            r.draw_line({x,y-10},{x,y-4},color,2.5f);r.draw_line({x,y-1},{x,y},color,2.5f);
        }
        if(storage_full){
            const float center=(!power_enabled || supply.warnings)?x+24:x;
            const Color amber{1.0f,0.68f,0.10f,1.0f};
            r.draw_rect({center-10,y-15,20,18},{0.05f,0.04f,0.02f,0.93f});
            // Crate outline with a nearly full fill bar, separate from supply warnings.
            r.draw_line({center-8,y-13},{center+8,y-13},amber,2);
            r.draw_line({center-8,y-13},{center-8,y+1},amber,2);
            r.draw_line({center+8,y-13},{center+8,y+1},amber,2);
            r.draw_line({center-8,y+1},{center+8,y+1},amber,2);
            r.draw_rect({center-4,y-8,8,6},amber);
        }
        if(inside){
            const std::string label="AIR "+std::to_string((int)std::lround(supply.breathability()))+"%";
            r.draw_rect({x-30,y+7,65,15},{0.02f,0.03f,0.04f,0.90f});
            game_label(r,{x-26,y+8},label,0.40f,theme_);
        }
    };
    const auto priority=[&](ConstructionTargetRef target,Vec3 position,float height){
        if(target.same_as(selected_construction_target()))return; // selected frame already labels its priority
        const auto rank=construction_priority_rank(target);const bool automatic=construction_automatic_priority(target);
        if((rank==kNoRobotIndex && !automatic) || construction_target_complete(target))return;
        float x=0,y=0;if(!project_world_to_logical(vp,position+Vec3{0,height+2.0f,0},r.width(),r.height(),ui_scale_,x,y))return;
        const Color c{0.28f,0.88f,1.0f,1};
        r.draw_rect({x+20,y-23,82,24},{0.02f,0.06f,0.09f,0.95f});
        r.draw_line({x+24,y-10},{x+29,y-16},c,2);r.draw_line({x+29,y-16},{x+34,y-10},c,2);
        game_label(r,{x+39,y-17},rank==kNoRobotIndex?"AUTO LINK":"PRIO "+std::to_string(rank+1),0.42f,theme_);
    };
    for(std::size_t i=0;i<placed_habitats_.size();++i)priority({ConstructionTargetKind::Habitat,i},placed_habitats_[i].position,habitat_models_.mesh(placed_habitats_[i]).height);
    for(std::size_t i=0;i<placed_resources_.size();++i)priority({ConstructionTargetKind::Resource,i},placed_resources_[i].position,resource_models_.mesh(placed_resources_[i]).height);
    const auto links=[&](const auto& connections,ConstructionTargetKind kind){for(std::size_t i=0;i<connections.size();++i){const auto& path=connections[i].path;if(!path.empty())priority({kind,i},path[path.size()/2],3);}};
    links(corridor_network_.connections(),ConstructionTargetKind::Corridor);links(utility_network_.connections(),ConstructionTargetKind::Utility);links(walkway_network_.connections(),ConstructionTargetKind::Walkway);
    for(const auto& h:placed_habitats_)if(h.construction.complete() || !h.power_enabled)
        draw(h.position,habitat_models_.mesh(h).height,h.supply,h.construction.complete(),false,h.power_enabled);
    for(const auto& q:placed_resources_)if(q.construction.complete() || !q.power_enabled){
        const bool dome=q.kind==ResourceKind::StorageDome;
        const bool full=dome && storage_dome_used_kg(q)>storage_dome_capacity_kg(q.storage_size)*kStorageDomeFullWarning;
        draw(q.position,resource_models_.mesh(q).height,q.supply,dome && q.construction.complete(),full,q.power_enabled);
    }
}

} // namespace game
