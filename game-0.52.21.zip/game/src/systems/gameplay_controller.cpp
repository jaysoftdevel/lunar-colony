#include "game/game_app.hpp"
#include "game/ui/layout.hpp"
#include "game/util/world_math.hpp"
#include "game/world/world_labels.hpp"
#include "game/version.hpp"
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <limits>
#include <sstream>

namespace game {
using namespace eng;
using namespace layout;
using namespace world_math;
using namespace world_labels;

float GameApp::game_speed_multiplier() const {
    switch(game_speed_){
        case GameSpeed::Normal: return 1.0f;
        case GameSpeed::Quick: return 2.0f;
        case GameSpeed::Fast: return 4.0f;
        case GameSpeed::Pause: return 0.0f;
    }
    return 1.0f;
}

bool GameApp::simulation_paused() const {
    return active_game_phase_==GamePhase::Planning?planning_.time_speed==0:game_speed_==GameSpeed::Pause;
}

void GameApp::update_speed_shortcuts(const InputState& in){
    const bool planning=active_game_phase_==GamePhase::Planning;
    const int current=planning?planning_.time_speed:(game_speed_==GameSpeed::Pause?0:static_cast<int>(game_speed_)+1);
    if(current>=1 && current<=3) last_running_speed_=static_cast<std::uint8_t>(current);

    auto next=in.key_number_pressed;
    if(in.key_space_pressed) next=current==0?last_running_speed_:0;
    else if(next<1 || next>3) return;
    if(next>0) last_running_speed_=next;
    if(planning) planning_.time_speed=next;
    else game_speed_=next>0?static_cast<GameSpeed>(next-1):GameSpeed::Pause;
}

void GameApp::update(float dt,const InputState& in){
    update_simulation(dt,in);
    update_activity_log();
    update_soundscape(dt,in);
}

void GameApp::update_simulation(float dt,const InputState& in){
    input_=in;
    if(graphics_benchmark_.running()){
        if(in.escape_pressed) graphics_benchmark_.stop(BenchmarkStatus::Cancelled);
        return;
    }

    // Keep the press pending until release. A right-button drag belongs to
    // the camera, and an active placement tool owns its cancellation click.
    const bool over_overlay=mouse_over_playfield_overlay(in);
    auto world_camera_input=in;
    if(over_overlay){
        world_camera_input.wheel=0.f;
        world_camera_input.right_down=false;
        world_camera_input.middle_down=false;
    }
    const bool selection_click=(in.right_pressed || right_click_pending_) && !over_overlay &&
        screen_==Screen::Playfield && active_game_phase_!=GamePhase::Planning &&
        first_person_mode_==FirstPersonMode::Off && !in.key_v_pressed && !in.escape_pressed &&
        !storage_gate_placement_active_ && !build_catalog_.selected() && corridor_link_source_<0 &&
        debug_move_pick_robot_<0 && !lander_.awaiting_site && !lander_.awaiting_stash;
    right_click_pending_=selection_click && in.right_down && !in.mouse_dx && !in.mouse_dy;
    if(selection_click && !in.right_down){
        clear_world_selection();
        selected_astronaut_=-1;
        selection_marquee_active_=false;
        selection_marquee_dragged_=false;
    }

    ui_time_seconds_+=std::max(0.0f,dt);
    if(dt>0.000001f){
        const float instant=1.0f/dt;
        fps_=fps_<=0.0f?instant:(fps_*0.90f+instant*0.10f);
    }

    if(screen_==Screen::Playfield){
        update_speed_shortcuts(in);
        if(active_game_phase_==GamePhase::Planning){
            // Stage 1 owns a separate company/mission-planning simulation. It
            // intentionally never advances Stage-2 robots, construction, colony
            // resources or first-person systems.
            if(in.escape_pressed){ screen_=Screen::MainMenu; return; }
            if(planning_.view==PlanningView::Site)
                camera_.update(world_camera_input,playfield_.size(),viewport_height_,dt);
            update_planning_game(dt);
            return;
        }
        if(debug_move_pick_robot_>=0 && (!debug_robot_move_available((std::size_t)debug_move_pick_robot_) || build_catalog_.selected()))debug_move_pick_robot_=-1;
        if(debug_move_pick_robot_>=0 && (in.escape_pressed || in.right_pressed)){debug_move_pick_robot_=-1;return;}

        if(lander_.awaiting_site||lander_.awaiting_stash){
            if(in.escape_pressed){screen_=Screen::MainMenu;return;}
            if(mouse_over_selection_panel(in)) world_camera_input.wheel=0;
            camera_.update(world_camera_input,playfield_.size(),viewport_height_,dt);
            Vec3 hit{};
            if(in.left_pressed && pick_lander_placement_ground(hit)){
                if(lander_.awaiting_site) confirm_lander_site(hit);
                else confirm_stash_site(hit);
            }
            return;
        }
        const float sim_dt=dt*game_speed_multiplier();
        const bool paused=simulation_paused();
        if(!paused){
            update_lunar_lander(sim_dt);
            if(active_game_phase_==GamePhase::RobotPreparation) update_trader(sim_dt);
        }
        const auto advance_colony=[&]{
            if(paused) return;
            status_.update(sim_dt);
            update_construction(sim_dt);
        };
        if(lander_.deploying()){
            if(in.escape_pressed){screen_=Screen::MainMenu;return;}
            if(lander_.in_flight()){
                const auto flight=lunar_lander_flight(lander_.elapsed);
                const Vec3 origin=lander_.site+Vec3{flight.offset.x*.5f,flight.offset.y*.45f,0};
                auto view=camera_.state();
                view.target=view.target-origin;
                camera_.restore(view);
                auto camera_input=world_camera_input;
                if(mouse_over_selection_panel(in))camera_input.wheel=0;
                camera_.update(camera_input,playfield_.size(),viewport_height_,dt);
                view=camera_.state();
                view.target+=origin;
                camera_.restore(view);
            }else{
                auto camera_input=world_camera_input;
                if(mouse_over_selection_panel(in))camera_input.wheel=0;
                camera_.update(camera_input,playfield_.size(),viewport_height_,dt);
                if(!over_overlay) update_selection_panel_scroll(in);
                const float y=(float)in.mouse_y/ui_scale_;
                if(in.left_pressed && !lander_.awaiting_stash && !over_overlay && y>=STATUS_BAR_H &&
                   y<(float)viewport_height_/ui_scale_-BUILD_BAR_H && !mouse_over_selection_panel(in))
                    select_world_at(in.mouse_x,in.mouse_y);
            }
            return;
        }
        if(!paused) update_pressure_doors(dt);
        if(in.key_v_pressed){
            selection_marquee_active_=false;
            selection_marquee_dragged_=false;
            if(first_person_mode_==FirstPersonMode::Off) enter_first_person_drop_mode();
            else exit_first_person_mode();
            return;
        }

        if(first_person_mode_==FirstPersonMode::DropPending){
            advance_colony();
            if(!paused && astronaut_test_active()) update_astronaut_test(sim_dt);
            if(in.escape_pressed){ exit_first_person_mode(); return; }
            camera_.update(world_camera_input,playfield_.size(),viewport_height_,dt);
            const float logical_y=(float)in.mouse_y/ui_scale_;
            const bool over_world=logical_y>=STATUS_BAR_H && logical_y<((float)viewport_height_/ui_scale_-BUILD_BAR_H);
            if(in.left_pressed && over_world && !over_overlay){
                Vec3 hit{};
                if(camera_.intersect_playfield(in.mouse_x,in.mouse_y,viewport_width_,viewport_height_,playfield_.size(),hit)){
                    // POV placement is exterior-only.  We still resolve the
                    // local surface height before validation so Air Lock access
                    // stairs and terrain are entered at the correct elevation;
                    // pressurised structures/corridors themselves are rejected.
                    Vec3 spawn{hit.x,first_person_floor_height(hit),hit.z};
                    if(first_person_spawn_valid(spawn)){
                        first_person_.spawn(spawn,camera_.azimuth_degrees());
                        first_person_mode_=FirstPersonMode::Active;
                        app_.set_relative_mouse_mode(true);
                    }
                }
            }
            return;
        }

        if(first_person_mode_==FirstPersonMode::Active){
            if(in.escape_pressed){ exit_first_person_mode(); return; }
            advance_colony();
            update_first_person(dt,in);
            if(!paused && astronaut_test_active()) update_astronaut_test(sim_dt);
            return;
        }

        // RMB is a fast cancel for every active build/placement tool. Consume
        // the click before camera panning so cancelling never nudges the view.
        if(in.right_pressed && storage_gate_placement_active_){
            selection_marquee_active_=false;
            selection_marquee_dragged_=false;
            storage_gate_placement_active_=false;
            storage_gate_placement_owner_=kNoRobotIndex;
            return;
        }
        if(in.right_pressed && build_catalog_.selected()!=nullptr){
            selection_marquee_active_=false;
            selection_marquee_dragged_=false;
            build_catalog_.clear_selection();
            placement_rotation_degrees_=0.0f;
            placement_habitat_size_=HabitatSizeTier::Small;
            placement_resource_size_=ResourceSizeTier::Small;
            placement_storage_size_=StorageDomeSize::Small;
            corridor_build_start_.reset();
            utility_build_start_.reset();
            walkway_build_start_.reset();
            walkway_build_target_.reset();
            corridor_link_source_=-1;
            return;
        }

        if(in.escape_pressed){
            selection_marquee_active_=false;
            selection_marquee_dragged_=false;
            // ESC cancels the most specific active gameplay operation first.
            if(storage_gate_placement_active_){
                storage_gate_placement_active_=false;
                storage_gate_placement_owner_=kNoRobotIndex;
                return;
            }
            if(build_catalog_.selected()!=nullptr){
                build_catalog_.clear_selection();
                placement_rotation_degrees_=0.0f;
                placement_habitat_size_=HabitatSizeTier::Small;
                placement_resource_size_=ResourceSizeTier::Small;
                placement_storage_size_=StorageDomeSize::Small;
                corridor_build_start_.reset();
                utility_build_start_.reset();
                walkway_build_start_.reset();
                walkway_build_target_.reset();
                return;
            }
            if(corridor_link_source_>=0){
                corridor_link_source_=-1;
                return;
            }
            if(astronaut_test_active() && selected_astronaut_>=0){
                selected_astronaut_=-1;
                return;
            }
            screen_=Screen::MainMenu;
            return;
        }

        if(in.delete_pressed && !storage_gate_placement_active_ && build_catalog_.selected()==nullptr && corridor_link_source_<0 && !corridor_build_start_ && !utility_build_start_ && !walkway_build_start_){
            delete_selected_world_object();
            return;
        }

        const bool over_panel=over_overlay || mouse_over_selection_panel(in);
        if(!over_overlay) update_selection_panel_scroll(in);
        InputState camera_input=world_camera_input;
        if(const BuildObjectDefinition* selected=build_catalog_.selected(); !over_panel && selected && (selected->kind==BuildObjectKind::Habitat || selected->kind==BuildObjectKind::Resource)){
            constexpr float step=15.0f;
            if(selected->kind==BuildObjectKind::Habitat){
                auto cycle_habitat=[&](int delta){
                    if(habitat_has_extended_size_tiers(selected->habitat_kind)){
                        constexpr HabitatSizeTier order[]{HabitatSizeTier::Small,HabitatSizeTier::Standard,HabitatSizeTier::Mid,HabitatSizeTier::Big};
                        int idx=0; for(int i=0;i<4;++i) if(order[i]==placement_habitat_size_) idx=i;
                        idx=(idx+delta+4)%4; placement_habitat_size_=order[idx];
                    }else{
                        constexpr HabitatSizeTier order[]{HabitatSizeTier::Small,HabitatSizeTier::Standard};
                        int idx=placement_habitat_size_==HabitatSizeTier::Small?0:1;
                        idx=(idx+delta+2)%2; placement_habitat_size_=order[idx];
                    }
                };
                if(in.wheel>0.0f) cycle_habitat(+1);
                if(in.wheel<0.0f) cycle_habitat(-1);
                camera_input.wheel=0.0f;
            }else if(selected->resource_kind==ResourceKind::StorageDome){
                auto cycle_storage=[&](int delta){
                    int v=(int)placement_storage_size_;
                    v=(v+delta+4)%4;
                    placement_storage_size_=(StorageDomeSize)v;
                };
                if(in.wheel>0.0f) cycle_storage(+1);
                if(in.wheel<0.0f) cycle_storage(-1);
                camera_input.wheel=0.0f;
            }else if(selected->resource_kind==ResourceKind::RobotWorkshop){
                placement_resource_size_=ResourceSizeTier::Standard;
                camera_input.wheel=0.0f;
            }else{
                auto cycle_resource=[&](int){
                    placement_resource_size_=placement_resource_size_==ResourceSizeTier::Small?ResourceSizeTier::Standard:ResourceSizeTier::Small;
                };
                if(in.wheel!=0.0f) cycle_resource(in.wheel>0.0f?1:-1);
                camera_input.wheel=0.0f;
            }
            // Mouse wheel is exclusively a structure-size control while a
            // structure is being placed. Rotation is keyboard-only (N/M).
            if(in.key_n_pressed) placement_rotation_degrees_=wrap_degrees(placement_rotation_degrees_-step);
            if(in.key_m_pressed) placement_rotation_degrees_=wrap_degrees(placement_rotation_degrees_+step);
        }
        const float pointer_y=(float)in.mouse_y/ui_scale_;
        if(pointer_y<STATUS_BAR_H || pointer_y>=(float)viewport_height_/ui_scale_-BUILD_BAR_H || over_panel)camera_input.wheel=0;
        camera_.update(camera_input,playfield_.size(),viewport_height_,dt);
        advance_colony();

        // World selection uses a click-or-drag marquee whenever no placement
        // tool is active. A short click keeps the old single-object selection;
        // dragging draws a screen-space pane and selects every ground resource
        // package whose projected center lies inside it.
        const float logical_y=(float)in.mouse_y/ui_scale_;
        const bool over_world=logical_y>=STATUS_BAR_H && logical_y<((float)viewport_height_/ui_scale_-BUILD_BAR_H);
        const bool selection_idle=!storage_gate_placement_active_ && build_catalog_.selected()==nullptr && corridor_link_source_<0 &&
                                  !corridor_build_start_ && !utility_build_start_ && !walkway_build_start_;
        if(astronaut_test_active()){
            if(!paused) update_astronaut_test(sim_dt);
            if(selection_idle && over_world && !over_panel && handle_astronaut_click(in)){
                selection_marquee_active_=false;
                return;
            }
        }
        if(debug_move_pick_robot_>=0 && in.left_pressed && over_world && !over_panel){
            Vec3 hit{};
            if(camera_.intersect_playfield(in.mouse_x,in.mouse_y,viewport_width_,viewport_height_,playfield_.size(),hit) &&
               issue_debug_robot_move((std::size_t)debug_move_pick_robot_,hit))debug_move_pick_robot_=-1;
            selection_marquee_active_=false;return;
        }
        if(debug_move_pick_robot_<0 && selection_idle && in.left_pressed && over_world && !over_panel){
            Vec3 hit{};
            if(camera_.intersect_playfield(in.mouse_x,in.mouse_y,viewport_width_,viewport_height_,playfield_.size(),hit)){
                selection_marquee_active_=true;
                selection_marquee_dragged_=false;
                selection_marquee_start_x_=in.mouse_x;
                selection_marquee_start_y_=in.mouse_y;
            }
        }
        if(selection_marquee_active_){
            const int dx=in.mouse_x-selection_marquee_start_x_;
            const int dy=in.mouse_y-selection_marquee_start_y_;
            if(std::sqrt((float)(dx*dx+dy*dy))>=6.0f*ui_scale_) selection_marquee_dragged_=true;
            if(!in.left_down) finish_selection_marquee();
        }
    } else if(in.escape_pressed) {
        // When the pause/game menu is open, ESC is a direct resume shortcut.
        // Sub-pages still use ESC to return one level to that menu first.
        if(screen_==Screen::MainMenu && game_session_active_) screen_=Screen::Playfield;
        else if(screen_==Screen::GraphicsSettings){
            if(graphics_dropdown_>=0)graphics_dropdown_=-1;
            else screen_=Screen::Settings;
        }
        else if(screen_==Screen::Stage3Modes){
            new_game_status_message_.clear();
            screen_=Screen::NewGame;
        }else if(screen_!=Screen::MainMenu) screen_=Screen::MainMenu;
    }
}

} // namespace game
