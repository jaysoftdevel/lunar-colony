#include "game/world/corridor/detail.hpp"
#include <array>
#include <limits>
#include <vector>

namespace game::corridor_detail {
void tri(std::vector<Vec3>& dst,Vec3 a,Vec3 b,Vec3 c){ dst.push_back(a); dst.push_back(b); dst.push_back(c); }
namespace {
float segment_distance_approx_for_self_test(Vec3 a0,Vec3 a1,Vec3 b0,Vec3 b1){
    float best=std::numeric_limits<float>::max();
    for(int i=0;i<=5;++i){
        const float t=(float)i/5.0f;
        const Vec3 p=a0+(a1-a0)*t;
        best=std::min(best,point_segment_distance_xz(p,b0,b1));
    }
    for(int i=0;i<=5;++i){
        const float t=(float)i/5.0f;
        const Vec3 p=b0+(b1-b0)*t;
        best=std::min(best,point_segment_distance_xz(p,a0,a1));
    }
    return best;
}
}

bool corridor_path_self_overlaps(const std::vector<Vec3>& path){
    constexpr float CLEARANCE=CORRIDOR_HALF_WIDTH*1.82f;
    if(path.size()<4) return false;
    std::vector<float> along(path.size(),0.0f);
    for(std::size_t i=1;i<path.size();++i) along[i]=along[i-1]+distance_xz(path[i-1],path[i]);
    for(std::size_t i=0;i+1<path.size();++i){
        const Vec3 di=flat_normal(path[i+1]-path[i]);
        const float li=distance_xz(path[i],path[i+1]);
        for(std::size_t j=i+2;j+1<path.size();++j){
            const float lj=distance_xz(path[j],path[j+1]);
            const float route_separation=(along[j]+lj*0.5f)-(along[i]+li*0.5f);
            if(route_separation<CORRIDOR_HALF_WIDTH*1.35f) continue;

            Vec3 hit{};
            if(segment_intersection_xz(path[i],path[i+1],path[j],path[j+1],hit,0.001f)) return true;

            const float spacing=segment_distance_approx_for_self_test(path[i],path[i+1],path[j],path[j+1]);
            if(spacing>=CLEARANCE) continue;
            const Vec3 dj=flat_normal(path[j+1]-path[j]);
            // Catch a tight hairpin even when its two legs do not mathematically
            // cross. Their swept pressure shells still overlap and form the
            // impassable knot seen in the 0.40.25 triangle save.
            if(length(di)>0.001f && length(dj)>0.001f && dot(di,dj)<-0.35f) return true;

            // For same-direction/non-hairpin portions retain the wider route-
            // distance exemption so ordinary smooth bends are not rejected.
            if(route_separation>=CLEARANCE*2.4f) return true;
        }
    }
    return false;
}

void edge(std::vector<Vec3>& dst,Vec3 a,Vec3 b){ dst.push_back(a); dst.push_back(b); }

std::vector<Vec2> corridor_cross_section(float scale){
    std::vector<Vec2> out;
    out.reserve(12);
    out.push_back({-CORRIDOR_HALF_WIDTH*scale,CORRIDOR_FLOOR_Y});
    out.push_back({ CORRIDOR_HALF_WIDTH*scale,CORRIDOR_FLOOR_Y});
    // Flat floor + short vertical walls + a rounded roof. This keeps the
    // pressure tube curved without producing a fully circular tunnel.
    constexpr int ARC=10;
    for(int i=0;i<=ARC;++i){
        const float a=(float)i/(float)ARC*PI;
        out.push_back({std::cos(a)*CORRIDOR_HALF_WIDTH*scale,
                       CORRIDOR_SIDE_Y+std::sin(a)*CORRIDOR_ROOF_RADIUS*scale});
    }
    return out;
}

Vec3 ring_vertex(Vec3 center,Vec3 side,const Vec2& q){
    return {center.x+side.x*q.x,center.y+q.y,center.z+side.z*q.x};
}

Vec3 path_tangent(const std::vector<Vec3>& path,std::size_t i){
    if(path.size()<2) return {1,0,0};
    if(i==0) return flat_normal(path[1]-path[0]);
    if(i+1>=path.size()) return flat_normal(path.back()-path[path.size()-2]);
    const Vec3 t=flat_normal(path[i+1]-path[i-1]);
    return length(t)>0.001f?t:flat_normal(path[i+1]-path[i]);
}

void append_swept_shell(CorridorMesh& mesh,const std::vector<Vec3>& path){
    if(path.size()<2) return;
    const auto section=corridor_cross_section();
    for(std::size_t i=0;i+1<path.size();++i){
        const Vec3 t0=path_tangent(path,i);
        const Vec3 t1=path_tangent(path,i+1);
        const Vec3 s0=perp_xz(t0);
        const Vec3 s1=perp_xz(t1);
        const Vec3 c0{path[i].x,path[i].y,path[i].z};
        const Vec3 c1{path[i+1].x,path[i+1].y,path[i+1].z};
        for(std::size_t j=0;j<section.size();++j){
            const std::size_t k=(j+1)%section.size();
            const Vec3 a=ring_vertex(c0,s0,section[j]);
            const Vec3 b=ring_vertex(c1,s1,section[j]);
            const Vec3 c=ring_vertex(c1,s1,section[k]);
            const Vec3 d=ring_vertex(c0,s0,section[k]);
            tri(mesh.shell,a,b,c); tri(mesh.shell,a,c,d);
        }
    }
}

void append_walkway(CorridorMesh& mesh,const std::vector<Vec3>& path){
    if(path.size()<2) return;
    for(std::size_t i=0;i+1<path.size();++i){
        const Vec3 t0=path_tangent(path,i),t1=path_tangent(path,i+1);
        const Vec3 s0=perp_xz(t0)*WALKWAY_HALF_WIDTH;
        const Vec3 s1=perp_xz(t1)*WALKWAY_HALF_WIDTH;
        const Vec3 p0{path[i].x,path[i].y+WALKWAY_Y,path[i].z};
        const Vec3 p1{path[i+1].x,path[i+1].y+WALKWAY_Y,path[i+1].z};
        tri(mesh.details,p0-s0,p1-s1,p1+s1);
        tri(mesh.details,p0-s0,p1+s1,p0+s0);
        edge(mesh.edges,p0-s0,p1-s1);
        edge(mesh.edges,p0+s0,p1+s1);
    }
}


namespace {
void append_detail_tube(CorridorMesh& mesh,Vec3 a,Vec3 b,float radius,int segments=6){
    const Vec3 axis=b-a;
    const float len=length(axis);
    if(len<0.001f) return;
    const Vec3 n=axis*(1.0f/len);
    const Vec3 ref=std::abs(n.y)<0.92f?Vec3{0,1,0}:Vec3{1,0,0};
    const Vec3 u=normalize(cross(n,ref));
    const Vec3 v=normalize(cross(n,u));
    segments=std::max(6,segments);
    for(int i=0;i<segments;++i){
        const float a0=2.0f*PI*(float)i/(float)segments;
        const float a1=2.0f*PI*(float)(i+1)/(float)segments;
        const Vec3 r0=(u*std::cos(a0)+v*std::sin(a0))*radius;
        const Vec3 r1=(u*std::cos(a1)+v*std::sin(a1))*radius;
        tri(mesh.details,a+r0,b+r0,b+r1);
        tri(mesh.details,a+r0,b+r1,a+r1);
        if(i%2==0){ edge(mesh.edges,a+r0,b+r0); }
    }
}
}

void append_pressure_services(CorridorMesh& mesh,const std::vector<Vec3>& path){
    if(path.size()<2) return;
    // Corridors are part of the colony utility backbone.  A dedicated water
    // pipe and redundant power conduits run continuously through the pressure
    // shell and follow the exact swept corridor path through bends/junctions.
    for(std::size_t i=0;i+1<path.size();++i){
        const Vec3 t0=path_tangent(path,i),t1=path_tangent(path,i+1);
        const Vec3 s0=perp_xz(t0),s1=perp_xz(t1);
        const Vec3 a=path[i],b=path[i+1];

        // Water main: deliberately larger and low in the service void.
        append_detail_tube(mesh,a+s0*(-1.15f)+Vec3{0,0.48f,0},
                                b+s1*(-1.15f)+Vec3{0,0.48f,0},0.058f,8);

        // Power backbone: two smaller redundant conduits on the opposite side.
        append_detail_tube(mesh,a+s0*(1.15f)+Vec3{0,0.48f,0},
                                b+s1*(1.15f)+Vec3{0,0.48f,0},0.033f,6);
        append_detail_tube(mesh,a+s0*(0.88f)+Vec3{0,2.22f,0},
                                b+s1*(0.88f)+Vec3{0,2.22f,0},0.026f,6);
    }
}

void append_deck_panels(CorridorMesh& mesh,const std::vector<Vec3>& path){
    if(path.size()<2) return;
    float next=0.70f;
    float travelled=0.0f;
    for(std::size_t i=0;i+1<path.size();++i){
        const float seg=distance_xz(path[i],path[i+1]);
        if(seg<0.001f) continue;
        while(travelled+seg>=next){
            const float t=(next-travelled)/seg;
            const Vec3 p=path[i]+(path[i+1]-path[i])*t;
            const Vec3 tangent=flat_normal(path[i+1]-path[i]);
            const Vec3 side=perp_xz(tangent)*WALKWAY_HALF_WIDTH;
            const Vec3 c=p+Vec3{0,WALKWAY_Y+0.012f,0};
            edge(mesh.edges,c-side,c+side);
            next+=1.10f;
        }
        travelled+=seg;
    }
}

void append_ring(CorridorMesh& mesh,Vec3 center,Vec3 tangent,float scale){
    tangent=flat_normal(tangent);
    if(length(tangent)<0.001f) return;
    const Vec3 side=perp_xz(tangent);
    const auto section=corridor_cross_section(scale);
    for(std::size_t j=0;j<section.size();++j){
        const std::size_t k=(j+1)%section.size();
        edge(mesh.edges,ring_vertex(center,side,section[j]),ring_vertex(center,side,section[k]));
    }
}

void append_ribs(CorridorMesh& mesh,const std::vector<Vec3>& path){
    if(path.size()<2) return;
    float next=1.7f;
    float travelled=0.0f;
    for(std::size_t i=0;i+1<path.size();++i){
        const float seg=distance_xz(path[i],path[i+1]);
        if(seg<0.001f) continue;
        while(travelled+seg>=next){
            const float t=(next-travelled)/seg;
            const Vec3 p=path[i]+(path[i+1]-path[i])*t;
            append_ring(mesh,{p.x,0,p.z},path[i+1]-path[i]);
            next+=1.7f;
        }
        travelled+=seg;
    }
}

} // namespace game::corridor_detail
